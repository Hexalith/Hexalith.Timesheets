using Hexalith.Timesheets.Contracts.Events.TimeEntries;
using Hexalith.Timesheets.Contracts.Events.MagicLinks;
using Hexalith.Timesheets.Contracts.Models;
using Hexalith.Timesheets.Contracts.References;
using Hexalith.Timesheets.Contracts.ValueObjects;
using Hexalith.Timesheets.Server.MagicLinks;

namespace Hexalith.Timesheets.Server.TimeEntries;

public sealed class TimeEntryState
{
    public bool IsRecorded { get; private set; }

    public TimeEntryId? TimeEntryId { get; private set; }

    public TimeEntryTargetReference? Target { get; private set; }

    public PartyReference? Contributor { get; private set; }

    public ActivityTypeId? ActivityTypeId { get; private set; }

    public ActivityTypeScope ActivityTypeScope { get; private set; }

    public DateOnly ServiceDate { get; private set; }

    public int DurationMinutes { get; private set; }

    public BillableState BillableState { get; private set; }

    public TimeEntryApprovalState ApprovalState { get; private set; }

    public ContributorCategory ContributorCategory { get; private set; }

    public AiEffortMetrics? AiMetrics { get; private set; }

    public TimeEntryComment? Comment { get; private set; }

    public ExternalContributionSource? ExternalSource { get; private set; }

    public ExternalContributionSource? ContributorConfirmationSource { get; private set; }

    public PartyReference? ConfirmedContributor { get; private set; }

    public TenantReference? ConfirmationTenant { get; private set; }

    public DateTimeOffset? ConfirmedAtUtc { get; private set; }

    public TimeEntrySubmissionId? TimeEntrySubmissionId { get; private set; }

    public PartyReference? Submitter { get; private set; }

    public TenantReference? SubmissionTenant { get; private set; }

    public DateTimeOffset? SubmittedAtUtc { get; private set; }

    public TimeEntrySubmissionScope SubmissionScope { get; private set; }

    public TimeEntryApprovalDecisionId? TimeEntryApprovalDecisionId { get; private set; }

    public PartyReference? Approver { get; private set; }

    public TenantReference? ApprovalTenant { get; private set; }

    public DateTimeOffset? DecidedAtUtc { get; private set; }

    public ApprovalAuthoritySourceAttribution? ApprovalAuthoritySource { get; private set; }

    public TimeEntryApprovalScope ApprovalScope { get; private set; }

    public TimeEntryRejectionReason? RejectionReason { get; private set; }

    public TimeEntryCorrectionState CorrectionState { get; private set; } = TimeEntryCorrectionState.None;

    public TimeEntryCorrectionId? TimeEntryCorrectionId { get; private set; }

    public PartyReference? CorrectedBy { get; private set; }

    public TenantReference? CorrectionTenant { get; private set; }

    public DateTimeOffset? CorrectedAtUtc { get; private set; }

    public TimeEntryApprovalDecisionId? RejectionDecisionId { get; private set; }

    public TimeEntryCorrectionValues? PreviousValues { get; private set; }

    public TimeEntryCorrectionValues? CorrectedValues { get; private set; }

    public TimeEntryCorrectionReason? CorrectionReason { get; private set; }

    public TimeEntryApprovalDecisionId? SourceApprovalDecisionId { get; private set; }

    public TimeEntryApprovalScope SourceApprovalScope { get; private set; }

    public TimeEntryExternalAdjustmentEvidence? ExternalAdjustment { get; private set; }

    /// <summary>Capability identifiers with a terminal transition owned by this Time Entry stream.</summary>
    public HashSet<string> TerminalMagicLinkCapabilityIds { get; private set; } = new(StringComparer.Ordinal);

    /// <summary>Whether a capability has conflicting terminal history in this stream.</summary>
    public bool HasAmbiguousMagicLinkTerminalHistory { get; private set; }

    /// <summary>Checks whether a capability has already reached a terminal state in this stream.</summary>
    public bool HasTerminalMagicLinkCapability(MagicLinkCapabilityId capabilityId)
        => TerminalMagicLinkCapabilityIds.Contains(capabilityId.Value);

    /// <summary>Records a capability use in this Time Entry stream.</summary>
    public void Apply(MagicLinkConfirmationCapabilityUsed used)
        => RecordTerminalCapability(used.CapabilityId);

    /// <summary>Applies an EventStore capability use payload.</summary>
    public void Apply(StoredMagicLinkUsed used) => Apply(used.Event);

    /// <summary>Records a capability revocation in this Time Entry stream.</summary>
    public void Apply(MagicLinkConfirmationCapabilityRevoked revoked)
        => RecordTerminalCapability(revoked.CapabilityId);

    /// <summary>Applies an EventStore capability revocation payload.</summary>
    public void Apply(StoredMagicLinkRevoked revoked) => Apply(revoked.Event);

    /// <summary>Records a capability expiry in this Time Entry stream.</summary>
    public void Apply(MagicLinkConfirmationCapabilityExpired expired)
        => RecordTerminalCapability(expired.CapabilityId);

    /// <summary>Applies an EventStore capability expiry payload.</summary>
    public void Apply(StoredMagicLinkExpired expired) => Apply(expired.Event);

    /// <summary>Applies an EventStore confirmation payload.</summary>
    public void Apply(StoredTimeEntryConfirmed confirmed) => Apply(confirmed.Event);

    /// <summary>Applies an EventStore adjustment payload.</summary>
    public void Apply(StoredTimeEntryAdjusted adjusted) => Apply(adjusted.Event);

    /// <summary>Applies an EventStore recording payload.</summary>
    public void Apply(StoredTimeEntryRecorded recorded) => Apply(recorded.Event);

    /// <summary>Applies an EventStore submission payload.</summary>
    public void Apply(StoredTimeEntrySubmitted submitted) => Apply(submitted.Event);

    /// <summary>Ignores a rejected command retained in the EventStore stream.</summary>
    public void Apply(MagicLinkCommitRejected rejected)
        => ArgumentNullException.ThrowIfNull(rejected);

    private void RecordTerminalCapability(MagicLinkCapabilityId capabilityId)
    {
        if (!TerminalMagicLinkCapabilityIds.Add(capabilityId.Value))
        {
            HasAmbiguousMagicLinkTerminalHistory = true;
        }
    }

    public TimeEntryLockState LockState => CorrectionState == TimeEntryCorrectionState.Superseded
        ? TimeEntryLockState.SupersededLocked
        : ApprovalState == TimeEntryApprovalState.Approved
            ? TimeEntryLockState.LockedFromDirectEdit
            : TimeEntryLockState.Unlocked;

    public bool IsLockedFromDirectEdit => LockState is TimeEntryLockState.LockedFromDirectEdit
        or TimeEntryLockState.SupersededLocked;

    public void Apply(TimeEntryRecorded recorded)
    {
        ArgumentNullException.ThrowIfNull(recorded);

        IsRecorded = true;
        TimeEntryId = recorded.TimeEntryId;
        Target = recorded.Target;
        Contributor = recorded.Contributor;
        ActivityTypeId = recorded.ActivityTypeId;
        ActivityTypeScope = recorded.ActivityTypeScope;
        ServiceDate = recorded.ServiceDate;
        DurationMinutes = recorded.DurationMinutes;
        BillableState = recorded.BillableState;
        ApprovalState = recorded.ApprovalState;
        ContributorCategory = recorded.ContributorCategory;
        AiMetrics = recorded.AiMetrics;
        Comment = recorded.Comment;
        ExternalSource = recorded.ExternalSource;
    }

    public void Apply(TimeEntrySubmitted submitted)
    {
        ArgumentNullException.ThrowIfNull(submitted);

        ApprovalState = submitted.ApprovalState;
        TimeEntrySubmissionId = submitted.TimeEntrySubmissionId;
        Submitter = submitted.Submitter;
        SubmissionTenant = submitted.Tenant;
        SubmittedAtUtc = submitted.SubmittedAtUtc;
        SubmissionScope = submitted.SubmissionScope;
    }

    public void Apply(TimeEntryContributorConfirmed confirmed)
    {
        ArgumentNullException.ThrowIfNull(confirmed);

        ConfirmedContributor = confirmed.Contributor;
        ConfirmationTenant = confirmed.Tenant;
        ConfirmedAtUtc = confirmed.ConfirmedAtUtc;
        ContributorConfirmationSource = confirmed.Source;
    }

    public void Apply(TimeEntryAdjustedThroughMagicLink adjusted)
    {
        ArgumentNullException.ThrowIfNull(adjusted);

        ActivityTypeId = adjusted.AdjustedValues.ActivityTypeId;
        ActivityTypeScope = adjusted.ActivityTypeScope;
        ServiceDate = adjusted.AdjustedValues.ServiceDate;
        DurationMinutes = adjusted.AdjustedValues.DurationMinutes;
        BillableState = adjusted.AdjustedValues.BillableState;
        ContributorCategory = adjusted.AdjustedValues.ContributorCategory;
        AiMetrics = adjusted.AdjustedValues.AiMetrics;
        Comment = adjusted.AdjustedValues.Comment;
        ExternalAdjustment = new(
            adjusted.TimeEntryId,
            adjusted.Contributor,
            adjusted.Tenant,
            adjusted.AdjustedAtUtc,
            adjusted.PreviousValues,
            adjusted.AdjustedValues,
            adjusted.Source);
    }

    public void Apply(TimeEntryApproved approved)
    {
        ArgumentNullException.ThrowIfNull(approved);

        ApprovalState = approved.ApprovalState;
        TimeEntryApprovalDecisionId = approved.TimeEntryApprovalDecisionId;
        Approver = approved.Approver;
        ApprovalTenant = approved.Tenant;
        DecidedAtUtc = approved.DecidedAtUtc;
        ApprovalAuthoritySource = approved.AuthoritySource;
        ApprovalScope = approved.ApprovalScope;
        RejectionReason = null;
    }

    public void Apply(TimeEntryRejected rejected)
    {
        ArgumentNullException.ThrowIfNull(rejected);

        ApprovalState = rejected.ApprovalState;
        TimeEntryApprovalDecisionId = rejected.TimeEntryApprovalDecisionId;
        Approver = rejected.Approver;
        ApprovalTenant = rejected.Tenant;
        DecidedAtUtc = rejected.DecidedAtUtc;
        ApprovalAuthoritySource = rejected.AuthoritySource;
        ApprovalScope = rejected.ApprovalScope;
        RejectionReason = rejected.Reason;
        RejectionDecisionId = rejected.TimeEntryApprovalDecisionId;
    }

    public void Apply(TimeEntryCorrected corrected)
    {
        ArgumentNullException.ThrowIfNull(corrected);

        Target = corrected.CorrectedValues.Target;
        Contributor = corrected.CorrectedValues.Contributor;
        ActivityTypeId = corrected.CorrectedValues.ActivityTypeId;
        // A missing scope is legacy evidence: preserve the preceding folded scope deterministically
        // instead of inferring ownership from a current catalog.
        ActivityTypeScope = corrected.CorrectedValues.ActivityTypeScope ?? ActivityTypeScope;
        ServiceDate = corrected.CorrectedValues.ServiceDate;
        DurationMinutes = corrected.CorrectedValues.DurationMinutes;
        BillableState = corrected.CorrectedValues.BillableState;
        ContributorCategory = corrected.CorrectedValues.ContributorCategory;
        AiMetrics = corrected.CorrectedValues.AiMetrics;
        Comment = corrected.CorrectedValues.Comment;
        ApprovalState = corrected.ApprovalState;
        CorrectionState = corrected.CorrectionState;
        TimeEntryCorrectionId = corrected.TimeEntryCorrectionId;
        CorrectedBy = corrected.CorrectedBy;
        CorrectionTenant = corrected.Tenant;
        CorrectedAtUtc = corrected.CorrectedAtUtc;
        RejectionDecisionId = corrected.RejectionDecisionId;
        PreviousValues = corrected.PreviousValues;
        CorrectedValues = corrected.CorrectedValues;
    }

    public void Apply(TimeEntryApprovedCorrected corrected)
    {
        ArgumentNullException.ThrowIfNull(corrected);

        Target = corrected.CorrectedValues.Target;
        Contributor = corrected.CorrectedValues.Contributor;
        ActivityTypeId = corrected.CorrectedValues.ActivityTypeId;
        // A missing scope is legacy evidence: preserve the preceding folded scope deterministically
        // instead of inferring ownership from a current catalog.
        ActivityTypeScope = corrected.CorrectedValues.ActivityTypeScope ?? ActivityTypeScope;
        ServiceDate = corrected.CorrectedValues.ServiceDate;
        DurationMinutes = corrected.CorrectedValues.DurationMinutes;
        BillableState = corrected.CorrectedValues.BillableState;
        ContributorCategory = corrected.CorrectedValues.ContributorCategory;
        AiMetrics = corrected.CorrectedValues.AiMetrics;
        Comment = corrected.CorrectedValues.Comment;
        ApprovalState = corrected.ApprovalState;
        CorrectionState = corrected.CorrectionState;
        TimeEntryCorrectionId = corrected.TimeEntryCorrectionId;
        CorrectedBy = corrected.CorrectedBy;
        CorrectionTenant = corrected.Tenant;
        CorrectedAtUtc = corrected.CorrectedAtUtc;
        PreviousValues = corrected.PreviousValues;
        CorrectedValues = corrected.CorrectedValues;
        CorrectionReason = corrected.Reason;
        SourceApprovalDecisionId = corrected.SourceApprovalDecisionId;
        SourceApprovalScope = corrected.SourceApprovalScope;
    }
}
