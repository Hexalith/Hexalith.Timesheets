using System.Text.Json;

using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Contracts.Streams;
using Hexalith.Timesheets.Contracts.Events.MagicLinks;
using Hexalith.Timesheets.Contracts.Events.TimeEntries;
using Hexalith.Timesheets.Contracts.Models;
using Hexalith.Timesheets.Contracts.References;
using Hexalith.Timesheets.Contracts.ValueObjects;
using Hexalith.Timesheets.Server.Runtime;
using Hexalith.Timesheets.Server.TimeEntries;

namespace Hexalith.Timesheets.Server.MagicLinks;

/// <summary>
/// Loads authoritative magic-link and Time Entry state from EventStore and combines it with the
/// rebuildable token-hash index and tenant Activity Type catalog.
/// </summary>
/// <param name="eventStore">The EventStore gateway used to replay authoritative streams.</param>
/// <param name="readModelStore">The read-model store used for non-authoritative index and catalog lookup.</param>
/// <param name="tokenGenerator">The canonical token hash derivation service.</param>
/// <param name="contextAccessor">The trusted ambient context used by administrator paths.</param>
/// <param name="indexCoordinator">The selected global candidate-index epoch, when registered.</param>
/// <param name="allowLegacyIndexRead">Explicit compatibility for isolated legacy loader fixtures.</param>
public sealed class EventStoreMagicLinkConfirmationCapabilityStateLoader(
    IEventStoreGatewayClient eventStore,
    IReadModelStore readModelStore,
    IMagicLinkTokenGenerator tokenGenerator,
    ITimesheetsTrustedContextAccessor contextAccessor,
    SharedProjectionEpochCoordinator? indexCoordinator = null,
    bool allowLegacyIndexRead = false) : IMagicLinkConfirmationCapabilityStateLoader
{
    private const int StreamPageSize = 500;

    private static readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web);

    private readonly IEventStoreGatewayClient _eventStore = eventStore ?? throw new ArgumentNullException(nameof(eventStore));
    private readonly IReadModelStore _readModelStore = readModelStore ?? throw new ArgumentNullException(nameof(readModelStore));
    private readonly IMagicLinkTokenGenerator _tokenGenerator = tokenGenerator ?? throw new ArgumentNullException(nameof(tokenGenerator));
    private readonly ITimesheetsTrustedContextAccessor _contextAccessor = contextAccessor ?? throw new ArgumentNullException(nameof(contextAccessor));
    private readonly SharedProjectionEpochCoordinator? _indexCoordinator = indexCoordinator;

    /// <inheritdoc/>
    public async ValueTask<ActivityTypeCatalogReadModel> LoadActivityTypeCatalogAsync(CancellationToken cancellationToken)
    {
        TenantReference? tenant = _contextAccessor.CurrentTenant;
        if (tenant is null)
        {
            return UnavailableCatalog();
        }

        return await LoadActivityTypeCatalogAsync(tenant, cancellationToken).ConfigureAwait(false);
    }

    /// <inheritdoc/>
    public async ValueTask<MagicLinkCapabilityState?> LoadCapabilityAsync(
        MagicLinkCapabilityId capabilityId,
        CancellationToken cancellationToken)
    {
        if (capabilityId is null)
        {
            return null;
        }

        TenantReference? tenant = _contextAccessor.CurrentTenant;
        if (tenant is null)
        {
            return null;
        }

        return await LoadCapabilityAsync(tenant, capabilityId, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>Loads only the different capability stream while the Time Entry actor owns processing.</summary>
    internal Task<MagicLinkCapabilityState?> LoadCapabilityStreamForTenantAsync(
        TenantReference tenant,
        MagicLinkCapabilityId capabilityId,
        CancellationToken cancellationToken)
        => LoadCapabilityAsync(tenant, capabilityId, cancellationToken, includeOwnerStream: false);

    /// <summary>Loads the tenant catalog without using a caller-supplied ambient claim.</summary>
    internal Task<ActivityTypeCatalogReadModel> LoadCatalogForTenantAsync(
        TenantReference tenant,
        CancellationToken cancellationToken)
        => LoadActivityTypeCatalogAsync(tenant, cancellationToken);

    /// <inheritdoc/>
    public async ValueTask<MagicLinkEndpointTokenState> LoadTokenStateAsync(
        string oneTimeToken,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(oneTimeToken))
        {
            return UnavailableTokenState();
        }

        MagicLinkTokenHash tokenHash;
        try
        {
            tokenHash = _tokenGenerator.DeriveHash(oneTimeToken);
        }
        catch (ArgumentException)
        {
            return UnavailableTokenState();
        }

        MagicLinkTokenHashCapabilityIndexEntry? candidate = await ResolveCandidateAsync(
            tokenHash,
            cancellationToken).ConfigureAwait(false);
        if (candidate is null)
        {
            return UnavailableTokenState();
        }

        MagicLinkCapabilityState? capability = await LoadCapabilityAsync(
            candidate.Tenant,
            candidate.CapabilityId,
            cancellationToken).ConfigureAwait(false);
        if (capability is null
            || capability.Tenant != candidate.Tenant
            || capability.CapabilityId != candidate.CapabilityId
            || capability.TokenHash != tokenHash
            || capability.TimeEntryId is null)
        {
            return UnavailableTokenState();
        }

        TimeEntryState? timeEntry = await LoadTimeEntryAsync(
            candidate.Tenant,
            capability.TimeEntryId,
            cancellationToken).ConfigureAwait(false);
        if (timeEntry is null
            || !timeEntry.IsRecorded
            || capability.ActivityTypeId is null
            || timeEntry.ActivityTypeId != capability.ActivityTypeId
            || timeEntry.ActivityTypeScope != ActivityTypeScope.Tenant)
        {
            return UnavailableTokenState();
        }

        ActivityTypeCatalogReadModel catalog = await LoadActivityTypeCatalogAsync(
            candidate.Tenant,
            cancellationToken).ConfigureAwait(false);
        if (catalog.ProjectionFreshness.State != ProjectionFreshnessState.Fresh)
        {
            // Retain only the sanitized catalog status for internal diagnosis. No resolved
            // capability, Time Entry, or catalog item can be used while the catalog is non-Fresh.
            return new MagicLinkEndpointTokenState(null, null, catalog);
        }

        ActivityTypeCatalogItem[] matchingActivityTypes = catalog.Items
            .Where(item => item.ActivityTypeId == capability.ActivityTypeId)
            .Take(2)
            .ToArray();
        // A matching catalog item is required to prove that the capability's Activity Type is still
        // present. The canonical catalog loader above already rejects duplicate, non-tenant, and
        // project-owned items, so only those ownership-shape checks are defence in depth. The
        // authoritative use-time ownership gate is the folded Time Entry scope check above.
        if (matchingActivityTypes.Length != 1
            || matchingActivityTypes[0].Scope != ActivityTypeScope.Tenant
            || matchingActivityTypes[0].Project is not null)
        {
            return UnavailableTokenState();
        }

        return new MagicLinkEndpointTokenState(capability, timeEntry, catalog);
    }

    private async Task<MagicLinkTokenHashCapabilityIndexEntry?> ResolveCandidateAsync(
        MagicLinkTokenHash tokenHash,
        CancellationToken cancellationToken)
    {
        try
        {
            MagicLinkTokenHashCapabilityIndexReadModel? value;
            long? selectedGeneration = null;
            string? selectedRootETag = null;
            if (_indexCoordinator is { } coordinator)
            {
                SharedProjectionScope scope = MagicLinkTokenHashCapabilityIndexProjection.GlobalScope();
                SharedProjectionReadResult<MagicLinkTokenHashCapabilityIndexTreeFormat> format = await coordinator
                    .ReadAsync<MagicLinkTokenHashCapabilityIndexTreeFormat>(scope,
                        MagicLinkTokenHashCapabilityIndexTreeReader.FormatKey, cancellationToken)
                    .ConfigureAwait(false);
                SharedProjectionReadResult<MagicLinkTokenHashCapabilityIndexTreeRoot> tree = await coordinator
                    .ReadAsync<MagicLinkTokenHashCapabilityIndexTreeRoot>(scope,
                        MagicLinkTokenHashCapabilityIndexTreeReader.RootKey, cancellationToken)
                    .ConfigureAwait(false);
                if (!format.IsAvailable || !tree.IsAvailable || format.IsStale || tree.IsStale)
                    return null;
                if (format.Value is not null || tree.Value is not null)
                {
                    if (format.Value?.StorageVersion != 7
                        || tree.Value is not { StorageVersion: 7 } numericRoot
                        || tree.Generation != format.Generation
                        || string.IsNullOrWhiteSpace(tree.SelectedETag)) return null;
                    var reader = new MagicLinkTokenHashCapabilityIndexTreeReader(coordinator, scope);
                    IReadOnlyList<MagicLinkTokenHashCapabilityIndexEntry> candidates = await reader
                        .FindCandidatesAsync(numericRoot.TokenRoot, tokenHash.Value, cancellationToken)
                        .ConfigureAwait(false);
                    if (candidates.Count != 1) return null;
                    SharedProjectionReadResult<MagicLinkTokenHashCapabilityIndexTreeRoot> rechecked =
                        await coordinator.ReadAsync<MagicLinkTokenHashCapabilityIndexTreeRoot>(scope,
                            MagicLinkTokenHashCapabilityIndexTreeReader.RootKey, cancellationToken)
                            .ConfigureAwait(false);
                    return rechecked.IsAvailable && !rechecked.IsStale
                        && rechecked.Generation == tree.Generation
                        && string.Equals(rechecked.SelectedETag, tree.SelectedETag, StringComparison.Ordinal)
                        ? candidates[0] : null;
                }
                SharedProjectionReadResult<MagicLinkTokenHashCapabilityIndexReadModel> selected = await coordinator
                    .ReadAsync<MagicLinkTokenHashCapabilityIndexReadModel>(
                        MagicLinkTokenHashCapabilityIndexProjection.GlobalScope(),
                        MagicLinkTokenHashCapabilityIndexProjection.ShardKey(tokenHash.Value),
                        cancellationToken).ConfigureAwait(false);
                value = selected.IsAvailable && !selected.IsStale ? selected.Value : null;
                selectedGeneration = selected.Generation;
                selectedRootETag = selected.SelectedETag;
            }
            else if (allowLegacyIndexRead)
            {
                // Legacy isolated loader fixtures continue to use the pre-epoch read-model seam.
                // The composed host registers the epoch coordinator and always takes the selected path.
                value = (await _readModelStore.GetAsync<MagicLinkTokenHashCapabilityIndexReadModel>(
                    MagicLinkTokenHashCapabilityIndexProjection.StateStoreName,
                    MagicLinkTokenHashCapabilityIndexProjection.StateKey,
                    cancellationToken).ConfigureAwait(false)).Value;
            }
            else return null;

            if (value is null
                || _indexCoordinator is not null && string.IsNullOrWhiteSpace(selectedRootETag)
                || !MagicLinkTokenHashCapabilityIndexProjection.HasValidPageManifest(value)
                || value.StorageVersion != MagicLinkTokenHashCapabilityIndexProjection.CurrentStorageVersion
                || value.LegacyContributionsUnverified
                || value.CandidatePageCounts.ContainsKey(tokenHash.Value))
            {
                return null;
            }

            // Validate the complete selected shard before publishing even an inline hit.
            // Otherwise an unread page can hide another owner for the same hash.
            int shard = MagicLinkTokenHashCapabilityIndexProjection.ShardOrdinal(tokenHash.Value);
            var selectedDirectory = new List<MagicLinkTokenHashCapabilityIndexDirectoryEntry>();
            foreach (MagicLinkTokenHashCapabilityIndexDirectoryReference reference in value.DirectoryPages)
            {
                if (_indexCoordinator is null) return null;
                ReadModelEntry<MagicLinkTokenHashCapabilityIndexDirectoryPage> selectedPage =
                    await _indexCoordinator.ReadGenerationAsync<MagicLinkTokenHashCapabilityIndexDirectoryPage>(
                        MagicLinkTokenHashCapabilityIndexProjection.GlobalScope(),
                        selectedGeneration!.Value,
                        MagicLinkTokenHashCapabilityIndexProjection.DirectoryPageKey(shard, reference.PageId),
                        cancellationToken).ConfigureAwait(false);
                if (!MagicLinkTokenHashCapabilityIndexProjection.HasValidDirectoryPage(value,
                        shard, reference, selectedPage.Value)) return null;
                if (selectedDirectory.Count > 0
                    && MagicLinkTokenHashCapabilityIndexProjection.CompareDirectoryRows(
                        selectedDirectory[^1], selectedPage.Value!.Entries[0]) >= 0) return null;
                selectedDirectory.AddRange(selectedPage.Value!.Entries);
            }
            foreach ((string hash, IReadOnlyList<int> pageIds) in value.CandidatePageIds)
            {
                if (_indexCoordinator is null) return null;
                foreach (int pageId in pageIds)
                {
                    ReadModelEntry<MagicLinkTokenHashCapabilityIndexPage> selectedPage =
                        await _indexCoordinator.ReadGenerationAsync<MagicLinkTokenHashCapabilityIndexPage>(
                            MagicLinkTokenHashCapabilityIndexProjection.GlobalScope(),
                            selectedGeneration!.Value,
                            MagicLinkTokenHashCapabilityIndexProjection.CandidatePageKey(shard, pageId),
                            cancellationToken).ConfigureAwait(false);
                    if (!MagicLinkTokenHashCapabilityIndexProjection.HasValidCandidatePage(value,
                            hash, pageId, selectedPage.Value)) return null;
                }
            }

            MagicLinkTokenHashCapabilityIndexEntry? candidate;
            if (value.Contributions.TryGetValue(tokenHash.Value, out var owners))
            {
                if (owners.Count != 1 || !value.Entries.TryGetValue(tokenHash.Value, out candidate)
                    || candidate != owners[0]) return null;
            }
            else
            {
                if (_indexCoordinator is null || value.Entries.ContainsKey(tokenHash.Value)) return null;
                MagicLinkTokenHashCapabilityIndexDirectoryEntry[] found = selectedDirectory
                    .Where(row => row.TokenHash == tokenHash.Value).ToArray();
                if (found.Length != 1) return null;
                candidate = found[0].Candidate;
            }

            if (candidate is null
                || string.IsNullOrWhiteSpace(candidate.Tenant.TenantId)
                || string.IsNullOrWhiteSpace(candidate.CapabilityId.Value)) return null;

            if (_indexCoordinator is { } selectedCoordinator)
            {
                SharedProjectionReadResult<MagicLinkTokenHashCapabilityIndexReadModel> rechecked =
                    await selectedCoordinator.ReadAsync<MagicLinkTokenHashCapabilityIndexReadModel>(
                        MagicLinkTokenHashCapabilityIndexProjection.GlobalScope(),
                        MagicLinkTokenHashCapabilityIndexProjection.ShardKey(shard),
                        cancellationToken).ConfigureAwait(false);
                if (!rechecked.IsAvailable || rechecked.IsStale
                    || rechecked.Generation != selectedGeneration
                    || !string.Equals(rechecked.SelectedETag, selectedRootETag, StringComparison.Ordinal))
                    return null;
            }

            return candidate;
        }
        catch (Exception ex) when (IsFailClosedReadException(ex, cancellationToken))
        {
            return null;
        }
    }

    private async Task<MagicLinkCapabilityState?> LoadCapabilityAsync(
        TenantReference tenant,
        MagicLinkCapabilityId capabilityId,
        CancellationToken cancellationToken,
        bool includeOwnerStream = true)
    {
        try
        {
            StreamReadEvent[] events = await ReadAllEventsAsync(
                tenant,
                capabilityId.Value,
                cancellationToken).ConfigureAwait(false);

            MagicLinkCapabilityState state = new();
            MagicLinkConfirmationCapabilityIssued? firstIssuance = null;
            int terminalCount = 0;
            foreach (StreamReadEvent streamEvent in events)
            {
                object? payload = Deserialize(
                    streamEvent,
                    typeof(MagicLinkConfirmationCapabilityIssued),
                    typeof(MagicLinkConfirmationCapabilityRevoked),
                    typeof(MagicLinkConfirmationCapabilityExpired),
                    typeof(MagicLinkConfirmationCapabilityUsed));
                if (payload is not null && !MatchesCapabilityIdentity(payload, tenant, capabilityId))
                {
                    throw new InvalidOperationException("A capability event does not match the requested stream identity.");
                }

                switch (payload)
                {
                    case MagicLinkConfirmationCapabilityIssued issued:
                        if (terminalCount != 0 || firstIssuance is not null)
                        {
                            throw new InvalidOperationException("A capability has ambiguous issuance history.");
                        }

                        firstIssuance ??= issued;
                        state.Apply(issued);
                        break;
                    case MagicLinkConfirmationCapabilityRevoked revoked:
                        terminalCount++;
                        state.Apply(revoked);
                        break;
                    case MagicLinkConfirmationCapabilityExpired expired:
                        terminalCount++;
                        state.Apply(expired);
                        break;
                    case MagicLinkConfirmationCapabilityUsed used:
                        terminalCount++;
                        state.Apply(used);
                        break;
                }
            }

            if (!state.Exists || terminalCount > 1 || state.TimeEntryId is null)
            {
                return null;
            }

            if (!includeOwnerStream)
            {
                return state;
            }

            // New terminal events belong to the Time Entry owner. Legacy terminal events in the
            // capability stream remain authoritative, and two terminal transitions fail closed.
            StreamReadEvent[] ownerEvents;
            try
            {
                ownerEvents = await ReadAllEventsAsync(
                    tenant, state.TimeEntryId.Value, cancellationToken).ConfigureAwait(false);
            }
            catch (EventStoreGatewayException ex) when (
                state.TargetKind == MagicLinkTargetKind.ProposedTimeEntry
                && ex.StatusCode == 404
                && string.Equals(ex.ReasonCode, StreamReplayReasonCodes.MissingStream, StringComparison.Ordinal))
            {
                // A proposed entry may not have an owner stream yet. A missing event,
                // malformed 404, or any other read failure still denies resolution.
                ownerEvents = [];
            }
            foreach (StreamReadEvent streamEvent in ownerEvents)
            {
                object? payload = Deserialize(
                    streamEvent,
                    typeof(MagicLinkConfirmationCapabilityUsed),
                    typeof(MagicLinkConfirmationCapabilityRevoked),
                    typeof(MagicLinkConfirmationCapabilityExpired));
                if (payload is null)
                {
                    continue;
                }

                if (payload is MagicLinkConfirmationCapabilityUsed ownerUse
                    && ownerUse.CapabilityId == capabilityId
                    && (ownerUse.Tenant != tenant || ownerUse.TimeEntryId != state.TimeEntryId))
                {
                    throw new InvalidOperationException("A capability use does not match its Time Entry owner.");
                }

                if (payload is MagicLinkConfirmationCapabilityRevoked ownerRevoke
                    && ownerRevoke.CapabilityId == capabilityId
                    && (ownerRevoke.Tenant != tenant || ownerRevoke.TimeEntryId != state.TimeEntryId))
                {
                    throw new InvalidOperationException("A capability revocation does not match its Time Entry owner.");
                }

                if (payload is MagicLinkConfirmationCapabilityExpired ownerExpire
                    && ownerExpire.CapabilityId == capabilityId
                    && (ownerExpire.Tenant != tenant || ownerExpire.TimeEntryId != state.TimeEntryId))
                {
                    throw new InvalidOperationException("A capability expiry does not match its Time Entry owner.");
                }

                if (payload is MagicLinkConfirmationCapabilityUsed used && used.CapabilityId == capabilityId)
                {
                    terminalCount++;
                    state.Apply(used);
                }
                else if (payload is MagicLinkConfirmationCapabilityRevoked revoked && revoked.CapabilityId == capabilityId)
                {
                    terminalCount++;
                    state.Apply(revoked);
                }
                else if (payload is MagicLinkConfirmationCapabilityExpired expired && expired.CapabilityId == capabilityId)
                {
                    terminalCount++;
                    state.Apply(expired);
                }
            }

            if (terminalCount > 1)
            {
                return null;
            }

            return state.Exists ? state : null;
        }
        catch (Exception ex) when (IsFailClosedReadException(ex, cancellationToken))
        {
            return null;
        }
    }

    private async Task<TimeEntryState?> LoadTimeEntryAsync(
        TenantReference tenant,
        TimeEntryId timeEntryId,
        CancellationToken cancellationToken)
    {
        try
        {
            StreamReadEvent[] events = await ReadAllEventsAsync(
                tenant,
                timeEntryId.Value,
                cancellationToken).ConfigureAwait(false);

            TimeEntryState state = new();
            foreach (StreamReadEvent streamEvent in events)
            {
                object? payload = Deserialize(
                    streamEvent,
                    typeof(TimeEntryRecorded),
                    typeof(TimeEntrySubmitted),
                    typeof(TimeEntryContributorConfirmed),
                    typeof(TimeEntryAdjustedThroughMagicLink),
                    typeof(TimeEntryApproved),
                    typeof(TimeEntryRejected),
                    typeof(TimeEntryCorrected),
                    typeof(TimeEntryApprovedCorrected),
                    typeof(MagicLinkConfirmationCapabilityUsed),
                    typeof(MagicLinkConfirmationCapabilityRevoked),
                    typeof(MagicLinkConfirmationCapabilityExpired));
                if (payload is not null && !MatchesTimeEntryIdentity(payload, tenant, timeEntryId))
                {
                    throw new InvalidOperationException("A Time Entry event does not match the requested stream identity.");
                }

                switch (payload)
                {
                    case TimeEntryRecorded recorded:
                        state.Apply(recorded);
                        break;
                    case TimeEntrySubmitted submitted:
                        state.Apply(submitted);
                        break;
                    case TimeEntryContributorConfirmed confirmed:
                        state.Apply(confirmed);
                        break;
                    case TimeEntryAdjustedThroughMagicLink adjusted:
                        if ((adjusted.PreviousValues.ActivityTypeScope is { } previousScope
                                && previousScope != state.ActivityTypeScope)
                            || (adjusted.AdjustedValues.ActivityTypeScope is { } adjustedScope
                                && adjustedScope != adjusted.ActivityTypeScope))
                        {
                            throw new InvalidOperationException(
                                "A Time Entry adjustment's explicit nested scopes do not match its authoritative scope lineage.");
                        }

                        state.Apply(adjusted);
                        break;
                    case TimeEntryApproved approved:
                        state.Apply(approved);
                        break;
                    case TimeEntryRejected rejected:
                        state.Apply(rejected);
                        break;
                    case TimeEntryCorrected corrected:
                        state.Apply(corrected);
                        break;
                    case TimeEntryApprovedCorrected corrected:
                        state.Apply(corrected);
                        break;
                    case MagicLinkConfirmationCapabilityUsed used:
                        state.Apply(used);
                        break;
                    case MagicLinkConfirmationCapabilityRevoked revoked:
                        state.Apply(revoked);
                        break;
                    case MagicLinkConfirmationCapabilityExpired expired:
                        state.Apply(expired);
                        break;
                }
            }

            return state.IsRecorded && !state.HasAmbiguousMagicLinkTerminalHistory ? state : null;
        }
        catch (Exception ex) when (IsFailClosedReadException(ex, cancellationToken))
        {
            return null;
        }
    }

    private async Task<ActivityTypeCatalogReadModel> LoadActivityTypeCatalogAsync(
        TenantReference tenant,
        CancellationToken cancellationToken)
    {
        try
        {
            ReadModelEntry<ActivityTypeCatalogReadModel> entry = await _readModelStore
                .GetAsync<ActivityTypeCatalogReadModel>(
                    MagicLinkActivityTypeCatalogReadModelAddress.StateStoreName,
                    MagicLinkActivityTypeCatalogReadModelAddress.StateKey(tenant),
                    cancellationToken)
                .ConfigureAwait(false);

            ActivityTypeCatalogReadModel? catalog = entry.Value;
            if (catalog?.ProjectionFreshness is null
                || !Enum.IsDefined(catalog.ProjectionFreshness.State)
                || catalog.Items is null
                || catalog.Items.Any(static item =>
                    item.Scope != ActivityTypeScope.Tenant
                    || item.Project is not null
                    || string.IsNullOrWhiteSpace(item.ActivityTypeId.Value)
                    || string.IsNullOrWhiteSpace(item.Label))
                || catalog.Items
                    .GroupBy(static item => item.ActivityTypeId.Value, StringComparer.Ordinal)
                    .Any(static group => group.Count() != 1))
            {
                return UnavailableCatalog();
            }

            return catalog.ProjectionFreshness.State == ProjectionFreshnessState.Fresh
                ? catalog
                : new ActivityTypeCatalogReadModel(
                    [],
                    ProjectionFreshnessMetadata.StatusOnly(catalog.ProjectionFreshness.State));
        }
        catch (Exception ex) when (IsFailClosedReadException(ex, cancellationToken))
        {
            return UnavailableCatalog();
        }
    }

    private async Task<StreamReadEvent[]> ReadAllEventsAsync(
        TenantReference tenant,
        string? aggregateId,
        CancellationToken cancellationToken)
    {
        List<StreamReadEvent> events = [];
        long fromSequence = 0;
        long latestSequence = 0;
        bool hasMore;

        do
        {
            StreamReadPage page = await _eventStore
                .ReadWorkloadStreamAsync(
                    new StreamReadRequest(
                        tenant.TenantId,
                        TimesheetsEventStoreIntegration.DomainName,
                        aggregateId,
                        FromSequence: fromSequence,
                        PageSize: StreamPageSize),
                    cancellationToken)
                .ConfigureAwait(false);

            if (!string.Equals(page.Tenant, tenant.TenantId, StringComparison.Ordinal)
                || !string.Equals(page.Domain, TimesheetsEventStoreIntegration.DomainName, StringComparison.Ordinal)
                || !string.Equals(page.AggregateId, aggregateId, StringComparison.Ordinal)
                || page.Metadata.FromSequence != fromSequence
                || page.Metadata.ToSequence is not null
                || page.Metadata.EventCount != page.Events.Count
                || page.Events.Any(item => item.SequenceNumber <= fromSequence)
                || (page.Events.Count > 0 && page.Metadata.LastSequenceReturned is null)
                || (page.Metadata.LastSequenceReturned is { } reportedLast
                    && (page.Events.Count == 0
                        || reportedLast != page.Events.Max(static item => item.SequenceNumber)))
                || page.Metadata.LatestSequence < latestSequence
                || page.Metadata.LatestSequence < (page.Metadata.LastSequenceReturned ?? 0))
            {
                throw new InvalidOperationException("The EventStore stream response did not match the requested scope.");
            }

            events.AddRange(page.Events);
            latestSequence = Math.Max(latestSequence, page.Metadata.LatestSequence);
            long? lastReturned = page.Metadata.LastSequenceReturned;
            if (lastReturned is null || lastReturned <= fromSequence)
            {
                if (page.Metadata.IsTruncated || latestSequence > fromSequence)
                {
                    throw new InvalidOperationException("The EventStore stream page did not advance its exclusive sequence cursor.");
                }

                break;
            }

            fromSequence = lastReturned.Value;
            hasMore = page.Metadata.IsTruncated || fromSequence < latestSequence;
        }
        while (hasMore);

        long expectedSequence = 1;
        HashSet<string> messageIds = new(StringComparer.Ordinal);
        List<StreamReadEvent> normalized = [];
        foreach (IGrouping<long, StreamReadEvent> group in events
            .GroupBy(static item => item.SequenceNumber)
            .OrderBy(static group => group.Key))
        {
            StreamReadEvent streamEvent = group.First();
            if (streamEvent.SequenceNumber != expectedSequence++)
            {
                throw new InvalidOperationException("The EventStore stream history is incomplete.");
            }

            if (group.Any(item => !Equivalent(item, streamEvent))
                || string.IsNullOrWhiteSpace(streamEvent.MessageId)
                || !messageIds.Add(streamEvent.MessageId))
            {
                throw new InvalidOperationException("The EventStore stream history is ambiguous.");
            }

            normalized.Add(streamEvent);
        }

        return normalized.ToArray();
    }

    private static bool Equivalent(StreamReadEvent left, StreamReadEvent right)
        => left.SequenceNumber == right.SequenceNumber
            && string.Equals(left.EventTypeName, right.EventTypeName, StringComparison.Ordinal)
            && PayloadsEqual(left.Payload, right.Payload)
            && string.Equals(left.SerializationFormat, right.SerializationFormat, StringComparison.OrdinalIgnoreCase)
            && left.MetadataVersion == right.MetadataVersion
            && string.Equals(left.MessageId, right.MessageId, StringComparison.Ordinal)
            && string.Equals(left.CorrelationId, right.CorrelationId, StringComparison.Ordinal)
            && string.Equals(left.CausationId, right.CausationId, StringComparison.Ordinal)
            && left.Timestamp == right.Timestamp
            && string.Equals(left.UserId, right.UserId, StringComparison.Ordinal)
            && Equals(left.ProtectionMetadata, right.ProtectionMetadata);

    private static bool PayloadsEqual(byte[]? left, byte[]? right)
        => left is null
            ? right is null
            : right is not null && left.AsSpan().SequenceEqual(right);

    private static object? Deserialize(StreamReadEvent streamEvent, params Type[] eventTypes)
    {
        string unqualifiedEventTypeName = streamEvent.EventTypeName.Split(',', 2)[0];
        (Type Stored, Type Domain)? stored = unqualifiedEventTypeName switch
        {
            var name when name == typeof(StoredMagicLinkIssued).FullName =>
                (typeof(StoredMagicLinkIssued), typeof(MagicLinkConfirmationCapabilityIssued)),
            var name when name == typeof(StoredMagicLinkUsed).FullName =>
                (typeof(StoredMagicLinkUsed), typeof(MagicLinkConfirmationCapabilityUsed)),
            var name when name == typeof(StoredMagicLinkRevoked).FullName =>
                (typeof(StoredMagicLinkRevoked), typeof(MagicLinkConfirmationCapabilityRevoked)),
            var name when name == typeof(StoredMagicLinkExpired).FullName =>
                (typeof(StoredMagicLinkExpired), typeof(MagicLinkConfirmationCapabilityExpired)),
            var name when name == typeof(StoredTimeEntryConfirmed).FullName =>
                (typeof(StoredTimeEntryConfirmed), typeof(TimeEntryContributorConfirmed)),
            var name when name == typeof(StoredTimeEntryAdjusted).FullName =>
                (typeof(StoredTimeEntryAdjusted), typeof(TimeEntryAdjustedThroughMagicLink)),
            var name when name == typeof(StoredTimeEntryRecorded).FullName =>
                (typeof(StoredTimeEntryRecorded), typeof(TimeEntryRecorded)),
            var name when name == typeof(StoredTimeEntrySubmitted).FullName =>
                (typeof(StoredTimeEntrySubmitted), typeof(TimeEntrySubmitted)),
            _ => null
        };
        Type? eventType = stored is { } matched && eventTypes.Contains(matched.Domain)
            ? matched.Stored
            : eventTypes.FirstOrDefault(type =>
            string.Equals(unqualifiedEventTypeName, type.Name, StringComparison.Ordinal)
            || string.Equals(unqualifiedEventTypeName, type.FullName, StringComparison.Ordinal));
        if (eventType is null)
        {
            return null;
        }

        if (!string.Equals(streamEvent.SerializationFormat, "json", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("A recognized EventStore event does not use JSON serialization.");
        }

        if (streamEvent.Payload is not { Length: > 0 })
        {
            throw new InvalidOperationException("A recognized EventStore event has an empty payload.");
        }

        using JsonDocument document = JsonDocument.Parse(streamEvent.Payload);

        object payload = JsonSerializer.Deserialize(document.RootElement, eventType, _jsonOptions)
            ?? throw new InvalidOperationException("A recognized EventStore event has a null payload.");
        return payload switch
        {
            StoredMagicLinkIssued item => RequiredStoredEvent(item.Event),
            StoredMagicLinkUsed item => RequiredStoredEvent(item.Event),
            StoredMagicLinkRevoked item => RequiredStoredEvent(item.Event),
            StoredMagicLinkExpired item => RequiredStoredEvent(item.Event),
            StoredTimeEntryConfirmed item => RequiredStoredEvent(item.Event),
            StoredTimeEntryAdjusted item => RequiredStoredEvent(item.Event),
            StoredTimeEntryRecorded item => RequiredStoredEvent(item.Event),
            StoredTimeEntrySubmitted item => RequiredStoredEvent(item.Event),
            _ => payload
        };
    }

    private static T RequiredStoredEvent<T>(T? value)
        where T : class
        => value ?? throw new InvalidOperationException("An EventStore payload has no domain event.");

    private static bool MatchesCapabilityIdentity(
        object payload,
        TenantReference tenant,
        MagicLinkCapabilityId capabilityId)
        => payload switch
        {
            MagicLinkConfirmationCapabilityIssued item => item.Tenant == tenant && item.CapabilityId == capabilityId,
            MagicLinkConfirmationCapabilityRevoked item => item.Tenant == tenant && item.CapabilityId == capabilityId,
            MagicLinkConfirmationCapabilityExpired item => item.Tenant == tenant && item.CapabilityId == capabilityId,
            MagicLinkConfirmationCapabilityUsed item => item.Tenant == tenant && item.CapabilityId == capabilityId,
            _ => false
        };

    private static bool MatchesTimeEntryIdentity(
        object payload,
        TenantReference tenant,
        TimeEntryId timeEntryId)
        => payload switch
        {
            TimeEntryRecorded item => item.TimeEntryId == timeEntryId,
            TimeEntrySubmitted item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryContributorConfirmed item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryAdjustedThroughMagicLink item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryApproved item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryRejected item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryCorrected item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            TimeEntryApprovedCorrected item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            MagicLinkConfirmationCapabilityUsed item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            MagicLinkConfirmationCapabilityRevoked item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            MagicLinkConfirmationCapabilityExpired item => item.Tenant == tenant && item.TimeEntryId == timeEntryId,
            _ => false
        };

    private static MagicLinkEndpointTokenState UnavailableTokenState()
        => new(null, null, UnavailableCatalog());

    private static ActivityTypeCatalogReadModel UnavailableCatalog()
        => new([], ProjectionFreshnessMetadata.Unavailable());

    private static bool IsFailClosedReadException(Exception exception, CancellationToken cancellationToken)
        => exception is not OperationCanceledException || !cancellationToken.IsCancellationRequested;
}
