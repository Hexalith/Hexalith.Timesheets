using Hexalith.Timesheets.Contracts.Models;
using Hexalith.Timesheets.Contracts.Models.MagicLinks;
using Hexalith.Timesheets.Contracts.Policies;
using Hexalith.Timesheets.Contracts.Queries.Reporting;
using Hexalith.Timesheets.Contracts.Ui;
using Hexalith.Timesheets.Contracts.ValueObjects;

namespace Hexalith.Timesheets.Contracts;

public static class TimesheetsMetadataCatalog
{
    public static IReadOnlyList<TimesheetsMetadataDescriptor> Descriptors { get; } =
    [
        new(
            "timesheets.command.record-time",
            "Record time",
            "capture",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("serviceDate", "Service date", "DateOnly", true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("aiMetrics", "AI effort metrics", nameof(AiEffortMetrics), false, "AI metrics keep runtime, effort, and token units explicit."),
                new("aiWallClockDurationMilliseconds", "AI wall-clock execution", "Milliseconds", false, "AI wall-clock execution time is recorded in milliseconds and kept separate from Duration minutes."),
                new("aiModelRuntimeMilliseconds", "AI model/tool runtime", "Milliseconds", false, "AI model or tool runtime is recorded in milliseconds."),
                new("aiBillableEffortMinutes", "AI billable effort", "WholeMinutes", false, "AI billable effort is recorded in minutes without converting token counts or runtime."),
                new("aiTokenAvailability", "AI token availability", nameof(AiTokenMetricAvailability), false, "Provider token counts use explicit text availability; unavailable counts stay null."),
                new("aiMetricSource", "AI metric source", nameof(AiEffortMetricSourceMetadata), false, "Compact audit source metadata without prompts, responses, secrets, request bodies, or personal data."),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Comments may be excluded by policy.")
            ],
            [
                new("record-time", "Record time", "Timesheets.RecordTime"),
                new("record-project-time", "Record project time", "Timesheets.RecordProjectTime"),
                new("record-work-time", "Record work time", "Timesheets.RecordWorkTime")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory)),
                new("ai-metrics", "AI metric availability", nameof(AiMetricAvailability)),
                new("ai-tokens", "AI token availability", nameof(AiTokenMetricAvailability)),
                new("ai-source", "AI metric source category", nameof(AiEffortMetricSourceCategory)),
                new("comment-retention", "Comment retention", nameof(TimesheetsEvidenceRetentionCategory))
            ]),
        new(
            "timesheets.command.submit-time-entries",
            "Submit entries",
            "submission",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("timeEntryIds", "Time Entries", "TimeEntryId[]", true, "Selected Draft entries remain visible before submission."),
                new("timeEntrySubmissionId", "Submission ID", nameof(TimeEntrySubmissionId), true),
                new("submissionScope", "Submission scope", nameof(TimeEntrySubmissionScope), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true, "Draft entries become Submitted when accepted."),
                new("blockingFields", "Blocking fields", "TimesheetsFieldError[]", false, "Invalid entries show correction fields without hiding selected entries."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true),
                new("partialSubmission", "Partial submission", "Boolean", false, "Valid entries and blocked entries are reported distinctly."),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Blocking policy and freshness messages persist across interrupted commands.")
            ],
            [
                new("submit-time-entries", "Submit entries", "Timesheets.SubmitTimeEntriesForApproval"),
                new("submit-for-approval", "Submit for approval", "Timesheets.SubmitForApproval")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.command.external-contribution",
            "External contributor",
            "external-contribution",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("source", "External source", nameof(ExternalContributionSource), true, "Safe source system and idempotency reference only."),
                new("timeEntry", "Time Entry", nameof(TimeEntryId), true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("confirmation", "Confirmation recorded", nameof(TimeEntryContributorConfirmationEvidence), false, "Contributor confirmation is evidence, not approval."),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true, "Approval still follows the configured Timesheets workflow."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("submit-external-time", "Submit external time", "Timesheets.SubmitExternalTimeEntry"),
                new("confirm-time", "Confirm time", "Timesheets.ConfirmExternalTimeEntry")
            ],
            [
                new("external-contributor", "External contributor", nameof(ContributorCategory)),
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.command.magic-link-adjustment",
            "Adjust external time",
            "external-contribution",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true, "Duration is edited in whole minutes."),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Comment submission follows the external display policy."),
                new("targetContext", "Target context", "String", true, "Read-only scoped target kind; target names are not exposed."),
                new("editableFields", "Editable fields", "String[]", true),
                new("readOnlyFields", "Read-only fields", "String[]", true),
                new("adjustmentOutcome", "Adjustment outcome", "String", true, "Status is shown with text, not color alone.")
            ],
            [
                new("display-adjustment", "Display adjustment", "Timesheets.DisplayMagicLinkAdjustment"),
                new("submit-adjustment", "Submit adjustment", "Timesheets.AdjustTimeThroughMagicLink")
            ],
            [
                new("billable", "Billable", nameof(BillableState)),
                new("adjustment-status", "Adjustment status", "String")
            ]),
        new(
            "timesheets.command.submit-period",
            "Submit period",
            "submission",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("timesheetPeriodId", "Timesheet Period", nameof(TimesheetPeriodId), true),
                new("contributor", "Contributor", "PartyReference", true),
                new("periodKind", "Period kind", nameof(TimesheetPeriodKind), true),
                new("localAnchorDate", "Local period date", "DateOnly", true, "Tenant-local period key is resolved from tenant policy."),
                new("timeEntryIds", "Time Entries", "TimeEntryId[]", true, "Draft and already Submitted entries remain visible before submission."),
                new("tenantTimeZoneId", "Tenant time-zone", "String", true, "Displayed from tenant policy; not accepted as caller authority."),
                new("periodState", "Period state", nameof(TimesheetPeriodApprovalState), true, "Period state stays separate from entry Approval State."),
                new("blockingEntryGuidance", "Blocking-entry guidance", nameof(TimesheetPeriodBlockingEntryGuidance), false, "Entry needs correction."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Blocking policy and freshness messages persist across interrupted commands.")
            ],
            [
                new("submit-period", "Submit period", "Timesheets.SubmitTimesheetPeriod"),
                new("submit-time-entries", "Submit entries", "Timesheets.SubmitTimeEntriesForApproval")
            ],
            [
                new("period", "Period", nameof(TimesheetPeriodApprovalState)),
                new("period-kind", "Period kind", nameof(TimesheetPeriodKind)),
                new("approval", "Entry approval", nameof(TimeEntryApprovalState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.command.correct-rejected-time-entry",
            "Correct entry",
            "correction",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("timeEntry", "Time Entry", "TimeEntryId", true),
                new("timeEntryCorrectionId", "Correction ID", nameof(TimeEntryCorrectionId), true),
                new("priorValues", "Prior values", nameof(TimeEntryCorrectionValues), true, "Prior rejected facts remain visible where authorized."),
                new("correctedValues", "Corrected values", nameof(TimeEntryCorrectionValues), true, "Corrected facts are submitted as a correction command."),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true, "Corrected duration supersedes the rejected value after acceptance."),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("aiMetrics", "AI effort metrics", nameof(AiEffortMetrics), false),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Correction comments are additive evidence."),
                new("rejectionReason", "Rejection reason", nameof(TimeEntryRejectionReason), true, "Rejection reason remains visible where authorized."),
                new("correctionState", "Correction state", nameof(TimeEntryCorrectionState), true),
                new("fieldValidation", "Field validation", "TimesheetsFieldError[]", false),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Policy, freshness, and permission messages persist across interrupted correction attempts.")
            ],
            [
                new("correct-entry", "Correct entry", "Timesheets.CorrectRejectedTimeEntry"),
                new("submit-corrected-entry", "Submit corrected entry", "Timesheets.SubmitTimeEntriesForApproval")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory))
            ]),
        new(
            "timesheets.command.correct-approved-time-entry",
            "Add correction",
            "correction",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("timeEntry", "Time Entry", "TimeEntryId", true),
                new("timeEntryCorrectionId", "Correction ID", nameof(TimeEntryCorrectionId), true),
                new("priorValues", "Prior values", nameof(TimeEntryCorrectionValues), true, "Prior approved facts remain visible where authorized."),
                new("correctedValues", "Corrected values", nameof(TimeEntryCorrectionValues), true, "Corrected facts are appended as correction evidence."),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true, "Corrected duration becomes the effective value without editing approved history."),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("aiMetrics", "AI effort metrics", nameof(AiEffortMetrics), false),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Correction comments are additive evidence."),
                new("reason", "Correction reason", nameof(TimeEntryCorrectionReason), true, "Correction reason is audit evidence and must remain policy-safe."),
                new("sourceApprovalDecisionId", "Source approval decision", nameof(TimeEntryApprovalDecisionId), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("correctionState", "Correction state", nameof(TimeEntryCorrectionState), true),
                new("lockState", "Lock state", nameof(TimeEntryLockState), true, "Corrected approved entries remain locked from direct edits."),
                new("fieldValidation", "Field validation", "TimesheetsFieldError[]", false),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Authority, freshness, and correction policy messages persist across interrupted correction attempts.")
            ],
            [
                new("add-correction", "Add correction", "Timesheets.CorrectApprovedTimeEntry")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("lock", "Lock", nameof(TimeEntryLockState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory))
            ]),
        new(
            "timesheets.command.activity-type-catalog",
            "Activity Type Catalog",
            "catalog",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("project", "Project reference", "ProjectReference", false),
                new("label", "Label", "String", true),
                new("scope", "Scope", nameof(ActivityTypeScope), true),
                new("billableDefault", "Billable default", nameof(BillableState), false)
            ],
            [
                new("create-tenant-activity-type", "Create tenant Activity Type", "Timesheets.CreateTenantActivityType"),
                new("create-project-activity-type", "Create project Activity Type", "Timesheets.CreateProjectActivityType"),
                new("rename-activity-type", "Rename Activity Type", "Timesheets.RenameActivityType"),
                new("update-billable-default", "Update billable default", "Timesheets.UpdateActivityTypeMetadata"),
                new("deactivate-activity-type", "Deactivate Activity Type", "Timesheets.DeactivateActivityType"),
                new("reactivate-activity-type", "Reactivate Activity Type", "Timesheets.ReactivateActivityType"),
                new("configure-project-catalog-restriction", "Restrict project Activity Type selection", "Timesheets.ConfigureProjectActivityTypeCatalogRestriction")
            ],
            [
                new("activity-type-scope", "Scope", nameof(ActivityTypeScope)),
                new("active-state", "Active state", nameof(ActivityTypeActiveState))
            ]),
        new(
            "timesheets.projection.activity-type-catalog",
            "Activity Type Catalog",
            "catalog",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("projectFilter", "Project filter", "ProjectReference", false, "Preserved when drilling into project-scoped catalog entries."),
                new("project", "Project reference", "ProjectReference", false),
                new("label", "Label", "String", true),
                new("scope", "Scope", nameof(ActivityTypeScope), true),
                new("activeState", "Active state", nameof(ActivityTypeActiveState), true),
                new("statusText", "Status text", "String", true, "Active and inactive state is shown as text."),
                new("billableDefault", "Billable default", nameof(BillableState), false),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("create-tenant-activity-type", "Create tenant Activity Type", "Timesheets.CreateTenantActivityType"),
                new("create-project-activity-type", "Create project Activity Type", "Timesheets.CreateProjectActivityType"),
                new("rename-activity-type", "Rename Activity Type", "Timesheets.RenameActivityType"),
                new("update-billable-default", "Update billable default", "Timesheets.UpdateActivityTypeMetadata"),
                new("deactivate-activity-type", "Deactivate Activity Type", "Timesheets.DeactivateActivityType"),
                new("reactivate-activity-type", "Reactivate Activity Type", "Timesheets.ReactivateActivityType"),
                new("configure-project-catalog-restriction", "Restrict project Activity Type selection", "Timesheets.ConfigureProjectActivityTypeCatalogRestriction")
            ],
            [
                new("active-state", "Active state", nameof(ActivityTypeActiveState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.dashboard.overview",
            "Timesheets Dashboard",
            "dashboard",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("tenantLocalPeriodKey", "Period", "TenantLocalPeriod", false, "Preserved across capture, review, approval, report, and ledger drill-in."),
                new("dateRange", "Date range", "DateOnlyRange", false, "Tenant-local filter context is preserved when returning from shortcuts."),
                new("projectFilter", "Project filter", "ProjectReference", false, "Stable Project reference only; labels hydrate on target surfaces after authorization."),
                new("workFilter", "Work filter", "WorkReference", false, "Stable Work reference only; labels hydrate on target surfaces after authorization."),
                new("currentPeriodState", "Current period state", nameof(TimesheetsDashboardCurrentPeriodState), true, "Text-bearing period status, not color-only state."),
                new("entryCount", "Current entries", "Integer", true),
                new("pendingSubmissionCount", "Pending submissions", "Integer", true),
                new("pendingCorrectionCount", "Pending corrections", "Integer", true),
                new("approvalWorkloadState", "Approval workload authority", nameof(TimesheetsDashboardAuthorityState), true, "Approval workload is hidden or disabled unless authority is resolved."),
                new("approvalSubmittedCount", "Submitted entries awaiting approval", "Integer", false),
                new("reportShortcuts", "Report shortcuts", nameof(TimesheetsDashboardShortcutReadModel), true, "Project, Work, and AI effort report shortcuts preserve filters."),
                new("ledgerReadiness", "Approved-Time Ledger readiness", nameof(TimesheetsDashboardLedgerReadinessSummary), true, "Ledger and export shortcuts are policy and freshness gated."),
                new("exportReadiness", "Export readiness", nameof(ApprovedTimeExportReadinessState), true, "Export is enabled only for fresh disclosed approved rows."),
                new("projectionStatuses", "Projection statuses", nameof(TimesheetsDashboardProjectionStatusReadModel), true, "Freshness and degraded states remain visible as persistent status."),
                new("freshnessMessage", "Freshness message", "FluentMessageBar", false, "Persistent stale, rebuilding, degraded, unavailable, or permission guidance."),
                new("emptyStateAction", "Empty state action", nameof(TimesheetsDashboardShortcutReadModel), true, "One safe action such as Record time.")
            ],
            [
                new("record-time", "Record time", "Timesheets.RecordTime"),
                new("open-my-period", "My Timesheet Period", "Timesheets.OpenMyTimesheetPeriod"),
                new("open-approvals", "Approvals Queue", "Timesheets.OpenApprovalsQueue"),
                new("open-project-report", "Project report", "Timesheets.QueryProjectActualTimeReport"),
                new("open-work-report", "Work report", "Timesheets.QueryWorkActualTimeReport"),
                new("open-ai-effort-report", "AI effort report", "Timesheets.QueryAiEffortReport"),
                new("open-approved-ledger", "Approved-Time Ledger", "Timesheets.QueryApprovedTimeLedger"),
                new("export-approved-ledger", "Export approved ledger", "Timesheets.GenerateApprovedLedgerExport")
            ],
            [
                new("current-period", "Current period", nameof(TimesheetsDashboardCurrentPeriodState)),
                new("shortcut-state", "Shortcut state", nameof(TimesheetsDashboardShortcutState)),
                new("shortcut-visibility", "Shortcut visibility", nameof(TimesheetsDashboardShortcutVisibility)),
                new("authority-state", "Authority state", nameof(TimesheetsDashboardAuthorityState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("decision-authority", "Decision authority", nameof(TimesheetsDashboardProjectionDecisionAuthority)),
                new("export-readiness", "Export readiness", nameof(ApprovedTimeExportReadinessState))
            ]),
        new(
            "timesheets.projection.time-entry-evidence",
            "Time Entry Evidence",
            "evidence",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("timeEntry", "Time Entry", "TimeEntryId", true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", "ActivityTypeId", true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("sourceAuthority", "Source authority", nameof(TimeEntryEvidenceSourceAuthority), true, "Timesheets domain events are the evidence source."),
                new("eventLineage", "Event lineage", nameof(TimeEntryEventLineageItem), true, "Safe event summaries for audit metadata."),
                new("approvalDecision", "Approval decision", nameof(TimeEntryApprovalDecisionEvidence), false, "Stable approval/rejection evidence for later locking, correction, and ledger projections."),
                new("approvalDecisionId", "Approval decision ID", nameof(TimeEntryApprovalDecisionId), false),
                new("approvalScope", "Approval scope", nameof(TimeEntryApprovalScope), false),
                new("approver", "Approver", "PartyReference", false),
                new("decidedAtUtc", "Decision time", "DateTimeOffset", false),
                new("lockEvidence", "Lock evidence", nameof(TimeEntryLockEvidence), true, "Direct-edit lock state derived from Time Entry domain events."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), true, "Approved entries are locked from direct edits."),
                new("rejectionReason", "Rejection reason", nameof(TimeEntryRejectionReason), false, "Required rejection reason preserved for correction workflow."),
                new("authoritySource", "Authority source", nameof(ApprovalAuthoritySource), false, "Stable source attribution for the approval decision."),
                new("authorityFreshness", "Authority freshness", nameof(ProjectionFreshnessState), false),
                new("displayHydration", "Display hydration", nameof(TimeEntryDisplayHydration), true, "Read-time labels keep explicit hydration state."),
                new("correction", "Correction evidence", nameof(TimeEntryCorrectionEvidence), false, "Original and corrected values are shown as additive lineage."),
                new("approvedCorrection", "Approved correction evidence", nameof(TimeEntryApprovedCorrectionEvidence), false, "Approved correction lineage is shown separately from rejected correction lineage."),
                new("correctionReason", "Correction reason", nameof(TimeEntryCorrectionReason), false, "Approved correction reason is visible only on authorized evidence surfaces."),
                new("aiMetrics", "AI effort metrics", nameof(AiEffortMetrics), false),
                new("aiWallClockDurationMilliseconds", "AI wall-clock execution", "Milliseconds", false, "AI wall-clock execution time is displayed separately from human/external duration."),
                new("aiModelRuntimeMilliseconds", "AI model/tool runtime", "Milliseconds", false, "AI model or tool runtime is displayed in milliseconds."),
                new("aiBillableEffortMinutes", "AI billable effort", "WholeMinutes", false, "AI billable effort is displayed in minutes without token-to-hours conversion."),
                new("aiTokenAvailability", "AI token availability", nameof(AiTokenMetricAvailability), false, "Unavailable provider token metrics are shown with explicit text, not zero or silence."),
                new("aiMetricSource", "AI metric source", nameof(AiEffortMetricSourceMetadata), false, "Compact audit source metadata for provider, tool, or work execution context."),
                new("correctionState", "Correction state", nameof(TimeEntryCorrectionState), true),
                new("priorValues", "Prior values", nameof(TimeEntryCorrectionValues), false),
                new("correctedValues", "Corrected values", nameof(TimeEntryCorrectionValues), false),
                new("fieldValidation", "Field validation", "TimesheetsFieldError[]", false),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Freshness and correction policy messages persist."),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Comments may contain sensitive information."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("correct-entry", "Correct entry", "Timesheets.CorrectRejectedTimeEntry"),
                new("add-correction", "Add correction", "Timesheets.CorrectApprovedTimeEntry"),
                new("review-export-policy", "Review export policy", "Timesheets.ReviewExportPolicy")
            ],
            [
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("source-authority", "Source authority", nameof(TimeEntryEvidenceSourceAuthority)),
                new("hydration-state", "Hydration state", nameof(DisplayHydrationState)),
                new("authority-decision", "Authority decision", nameof(ApprovalAuthorityDecisionState)),
                new("authority-source", "Authority source", nameof(ApprovalAuthoritySource)),
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("lock", "Lock", nameof(TimeEntryLockState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("ai-metrics", "AI metric availability", nameof(AiMetricAvailability)),
                new("ai-tokens", "AI token availability", nameof(AiTokenMetricAvailability)),
                new("ai-source", "AI metric source category", nameof(AiEffortMetricSourceCategory)),
                new("comment-export", "Comment export", nameof(TimesheetsCommentPolicyDecision))
            ]),
        new(
            "timesheets.projection.time-entry-query",
            "Time Entry Query",
            "evidence",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("contributorFilter", "Contributor filter", "PartyReference", false, "Preserved during drill-in and back navigation."),
                new("projectFilter", "Project filter", "ProjectReference", false, "Project-target rows validate Project authority only."),
                new("workFilter", "Work filter", "WorkReference", false, "Work-target rows validate Work authority only."),
                new("periodFilter", "Period filter", "TenantLocalPeriod", false, "Tenant-local period or date range."),
                new("activityTypeFilter", "Activity Type filter", nameof(ActivityTypeId), false),
                new("billableFilter", "Billable filter", nameof(BillableState), false),
                new("approvalStateFilter", "Approval state filter", nameof(TimeEntryApprovalState), false),
                new("correctionStateFilter", "Correction state filter", nameof(TimeEntryCorrectionState), false),
                new("sourceTypeFilter", "Source type filter", nameof(TimeEntrySourceType), false, "Derived from contributor category plus external source or AI metrics evidence."),
                new("timeEntry", "Time Entry", nameof(TimeEntryId), true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("correctionState", "Correction state", nameof(TimeEntryCorrectionState), true),
                new("sourceType", "Source type", nameof(TimeEntrySourceType), true, "Shown as text-bearing status."),
                new("displayHydration", "Display hydration", nameof(TimeEntryDisplayHydration), true, "Labels are hydrated only after row authorization succeeds."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true, "Fresh, stale, rebuilding, degraded, or unavailable state remains visible.")
            ],
            [
                new("drill-into-evidence", "Open evidence", "Timesheets.ReadTimeEntryEvidence"),
                new("query-time-entries", "Query entries", "Timesheets.QueryTimeEntries")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("billable", "Billable", nameof(BillableState)),
                new("source-type", "Source type", nameof(TimeEntrySourceType)),
                new("hydration-state", "Hydration state", nameof(DisplayHydrationState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.projection.approved-time-ledger",
            "Approved-Time Ledger",
            "reporting",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("projectFilter", "Project filter", "ProjectReference", false, "Project-target rows validate Project authority only."),
                new("workFilter", "Work filter", "WorkReference", false, "Work-target rows validate Work authority only."),
                new("contributorFilter", "Contributor filter", "PartyReference", false, "Preserved during drill-in and back navigation."),
                new("activityTypeFilter", "Activity Type filter", nameof(ActivityTypeId), false),
                new("periodFilter", "Period filter", "TenantLocalPeriod", false, "Tenant-local period or date range."),
                new("billableFilter", "Billable filter", nameof(BillableState), false),
                new("currentRowsOnly", "Current rows only", "Boolean", true, "Superseded rows are hidden unless explicitly requested."),
                new("includeSupersededRows", "Include superseded rows", "Boolean", false, "Shows prior approved evidence for reconciliation."),
                new("projectionFreshnessFilter", "Projection freshness filter", nameof(ProjectionFreshnessState), false),
                new("timeEntry", "Time Entry", nameof(TimeEntryId), true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("serviceDate", "Service date", "DateOnly", true),
                new("durationMinutes", "Duration minutes", "WholeMinutes", true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("approvalDecision", "Approval decision", nameof(TimeEntryApprovalDecisionEvidence), true, "Stable approval metadata for downstream evidence."),
                new("approvedCorrection", "Approved correction", nameof(TimeEntryApprovedCorrectionEvidence), false, "Approved correction lineage remains visible for reconciliation."),
                new("correction", "Correction lineage", nameof(TimeEntryCorrectionEvidence), false, "Rejected-entry correction lineage remains visible after later approval."),
                new("lockEvidence", "Lock evidence", nameof(TimeEntryLockEvidence), true, "Approved rows are locked from direct entry edits."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), true),
                new("rowState", "Ledger row state", nameof(ApprovedTimeLedgerRowState), true, "Current and superseded rows are text-bearing status."),
                new("displayHydration", "Display hydration", nameof(TimeEntryDisplayHydration), true, "Labels are hydrated only after row authorization succeeds."),
                new("commentPolicy", "Comment policy", nameof(TimesheetsCommentPolicyDecision), true, "Comment text is omitted unless projection policy allows it."),
                new("comment", "Comment", nameof(TimeEntryComment), false, "Comments may be excluded by policy."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true, "Fresh, stale, rebuilding, degraded, or unavailable state remains visible."),
                new("exportReadiness", "Export readiness", nameof(ApprovedTimeExportReadinessState), true, "Ready only when disclosed billable rows are fresh and policy allows export."),
                new("exportOutputScope", "Export output scope", nameof(ApprovedTimeExportScope), false, "Row count and selected filters are reviewed before export."),
                new("includedEvidenceFields", "Included evidence fields", "String[]", false, "Stable IDs, approval metadata, correction lineage, event lineage, AI evidence units, and policy-allowed comments."),
                new("exportFormat", "Export format", nameof(ApprovedTimeExportFormat), true, "CSV v1 evidence export."),
                new("exportAuditMetadata", "Export audit metadata", nameof(ApprovedTimeExportAuditMetadata), false, "Requester, tenant, filters, timestamps, correlation ID, output scope, format, freshness, row count, content fingerprint, and block status."),
                new("exportAuditEvidence", "Export audit evidence", "ApprovedTimeExported", false, "Accepted exports emit domain-event evidence with safe references, filter snapshot, UTC timestamps, output scope, format, freshness, row count, and content fingerprint."),
                new("exportReviewDialog", "Export Review Dialog", "FluentDialog", false, "One bounded dialog summarizes selected filters, output scope, evidence fields, freshness state, comment policy, audit metadata, and non-calculation boundaries."),
                new("exportBlockMessage", "Export block message", "FluentMessageBar", false, "Persistent stale, no-results, permission, or policy block explanation."),
                new("exportSuccessFeedback", "Export success feedback", "FluentToast", false, "Transient feedback only after successful export generation.")
            ],
            [
                new("drill-into-evidence", "Open evidence", "Timesheets.ReadTimeEntryEvidence"),
                new("query-approved-time-ledger", "Query ledger", "Timesheets.QueryApprovedTimeLedger"),
                new("review-export-readiness", "Review export readiness", "Timesheets.ReviewExportReadiness"),
                new("export-approved-ledger", "Export approved ledger", "Timesheets.GenerateApprovedLedgerExport")
            ],
            [
                new("billable", "Billable", nameof(BillableState)),
                new("ledger-row", "Ledger row", nameof(ApprovedTimeLedgerRowState)),
                new("lock", "Lock", nameof(TimeEntryLockState)),
                new("hydration-state", "Hydration state", nameof(DisplayHydrationState)),
                new("authority-source", "Approval authority source", nameof(ApprovalAuthoritySource)),
                new("comment-policy", "Comment policy", nameof(TimesheetsCommentPolicyDecision)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("export-readiness", "Export readiness", nameof(ApprovedTimeExportReadinessState)),
                new("export-format", "Export format", nameof(ApprovedTimeExportFormat))
            ]),
        new(
            "timesheets.command.approved-ledger-export",
            "Export approved ledger",
            "reporting",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("ledgerQuery", "Selected filters", nameof(QueryApprovedTimeLedger), true, "Reuses Approved-Time Ledger filters for Project, Work, Contributor, Activity Type, period, date range, billable flag, and row lineage options."),
                new("outputScope", "Output scope", nameof(ApprovedTimeExportScope), true, "Previewed row count and row-state options before generation."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true, "Freshness must be Fresh before export is enabled."),
                new("exportReadiness", "Export readiness", nameof(ApprovedTimeExportReadinessState), true, "Blocked exports show a persistent explanation and produce no file."),
                new("commentPolicy", "Comment policy", nameof(TimesheetsCommentPolicyDecision), true, "Comments are exported only when policy allows."),
                new("includedEvidenceFields", "Included evidence fields", "String[]", true, "Stable IDs, target references, dates, durations, activity type, billable flag, approval metadata, correction lineage, event lineage, and allowed comments."),
                new("auditMetadata", "Audit metadata", nameof(ApprovedTimeExportAuditMetadata), true, "Requester, tenant, filters, timestamps, correlation ID, output scope, format, freshness, row count, content fingerprint, and block status."),
                new("auditEvidence", "Audit evidence", "ApprovedTimeExported", false, "Generated exports emit domain-event evidence without CSV rows, comments, display labels, credential material, caller bodies, or sibling-owned state."),
                new("reviewDialog", "Review dialog", "FluentDialog", true, "One bounded confirmation dialog for filters, scope, evidence fields, freshness, policy, and non-calculation boundaries."),
                new("persistentBlock", "Persistent block", "FluentMessageBar", false, "Used for stale projection, no results, permission denial, or policy block."),
                new("successFeedback", "Success feedback", "FluentToast", false, "Used only after a successful export request.")
            ],
            [
                new("generate-approved-ledger-export", "Export approved ledger", "Timesheets.GenerateApprovedLedgerExport")
            ],
            [
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("comment-policy", "Comment policy", nameof(TimesheetsCommentPolicyDecision)),
                new("export-readiness", "Export readiness", nameof(ApprovedTimeExportReadinessState)),
                new("export-format", "Export format", nameof(ApprovedTimeExportFormat))
            ]),
        new(
            "timesheets.query.approved-ledger-export-preview",
            "Preview approved ledger export",
            "reporting",
            TimesheetsSurfaceKind.Query,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("ledgerQuery", "Selected filters", nameof(QueryApprovedTimeLedger), true, "Reuses Approved-Time Ledger filters for Project, Work, Contributor, Activity Type, period, date range, billable flag, and row lineage options."),
                new("outputScope", "Output scope", nameof(ApprovedTimeExportScope), true, "Previewed row count and row-state options; preview returns this scope without producing a file."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true, "Freshness must be Fresh before the previewed scope is ready; stale, rebuilding, or unavailable projections preview as blocked."),
                new("exportReadiness", "Export readiness", nameof(ApprovedTimeExportReadinessState), true, "Ready or Blocked readiness only; preview produces no file and records no audit evidence."),
                new("commentPolicy", "Comment policy", nameof(TimesheetsCommentPolicyDecision), true, "Effective export comment-policy decision applied to the previewed scope."),
                new("billableFilter", "Billable filter", nameof(BillableState), true, "Approved billable evidence is required; a non-billable filter previews as blocked."),
                new("readinessDetail", "Readiness detail", "String", false, "Readiness explanation reusing export-generation vocabulary; no row, comment, or file content is disclosed."),
                new("persistentBlock", "Persistent block", "FluentMessageBar", false, "Used for stale projection, no results, permission denial, or policy block before export."),
                new("reviewDialog", "Review dialog", "FluentDialog", false, "Preview is the readiness step before the bounded export review dialog.")
            ],
            [
                new("review-export-readiness", "Review export readiness", "Timesheets.ReviewExportReadiness")
            ],
            [
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState)),
                new("comment-policy", "Comment policy", nameof(TimesheetsCommentPolicyDecision)),
                new("export-readiness", "Export readiness", nameof(ApprovedTimeExportReadinessState)),
                new("export-format", "Export format", nameof(ApprovedTimeExportFormat)),
                new("billable", "Billable", nameof(BillableState))
            ]),
        new(
            "timesheets.projection.project-actual-time-report",
            "Project Actual-Time Report",
            "reporting",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("projectFilter", "Project filter", "ProjectReference", false, "Project references remain stable IDs; labels hydrate after authorization."),
                new("contributorFilter", "Contributor filter", "PartyReference", false, "Preserved during drill-in and back navigation."),
                new("activityTypeFilter", "Activity Type filter", nameof(ActivityTypeId), false),
                new("periodFilter", "Period filter", "TenantLocalPeriod", false, "Tenant-local period or date range."),
                new("billableFilter", "Billable filter", nameof(BillableState), false),
                new("approvalStateFilter", "Approval state filter", nameof(TimeEntryApprovalState), false),
                new("contributorCategoryFilter", "Contributor category filter", nameof(ContributorCategory), false),
                new("aiAgentFilter", "AI agent filter", "PartyReference", false, "Automated agent Party filter for AI effort rows."),
                new("aiMetricAvailabilityFilter", "AI metric availability filter", nameof(AiMetricAvailability), false),
                new("aiTokenAvailabilityFilter", "AI token availability filter", nameof(AiTokenMetricAvailability), false, "Unavailable and Not reported by provider are displayed as text."),
                new("aiSourceCategoryFilter", "AI source category filter", nameof(AiEffortMetricSourceCategory), false),
                new("currentRowsOnly", "Current rows only", "Boolean", true, "Superseded evidence is hidden unless explicitly requested."),
                new("includeSupersededRows", "Include superseded rows", "Boolean", false, "Shows superseded evidence only for reconciliation."),
                new("projectionFreshnessFilter", "Projection freshness filter", nameof(ProjectionFreshnessState), false),
                new("target", "Project reference", "ProjectReference", true),
                new("tenantLocalPeriodKey", "Period", "TenantLocalPeriod", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("actualMinutes", "Actual minutes", "WholeMinutes", true),
                new("aiWallClockDurationMilliseconds", "AI wall-clock execution", "Milliseconds", false, "AI wall-clock execution stays separate from human and external minutes."),
                new("aiModelRuntimeMilliseconds", "AI model/tool runtime", "Milliseconds", false),
                new("aiBillableEffortMinutes", "AI billable effort", "WholeMinutes", false, "AI billable effort stays separate from actual minutes and provider token counts."),
                new("aiProviderInputTokenCount", "Provider input tokens", "Integer", false, "Unavailable token counts display Unavailable or Not reported by provider, never zero unless reported as zero."),
                new("aiProviderOutputTokenCount", "Provider output tokens", "Integer", false, "Unavailable token counts display Unavailable or Not reported by provider, never zero unless reported as zero."),
                new("aiProviderTotalTokenCount", "Provider total tokens", "Integer", false, "Provider-reported token count only."),
                new("aiMetricAvailability", "AI metric availability", nameof(AiMetricAvailability), true),
                new("aiTokenAvailability", "AI token availability", nameof(AiTokenMetricAvailability), true, "Unavailable or Not reported by provider."),
                new("aiMetricSourceCategory", "AI source category", nameof(AiEffortMetricSourceCategory), false),
                new("aiMetricSourceMetadata", "AI metric source metadata", nameof(AiEffortMetricSourceMetadata), false, "Compact provider, tool, or work execution reference only."),
                new("sourceRowCount", "Source rows", "Integer", true),
                new("correctionCount", "Corrections", "Integer", true),
                new("supersededCount", "Superseded rows", "Integer", true),
                new("referenceState", "Reference state", nameof(ActualTimeReferenceState), true),
                new("displayHydration", "Display hydration", nameof(TimeEntryDisplayHydration), true, "Labels are hydrated only after row authorization succeeds."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("query-project-actual-time-report", "Query Project report", "Timesheets.QueryProjectActualTimeReport"),
                new("open-work-actual-time-report", "Open Work report", "Timesheets.QueryWorkActualTimeReport"),
                new("drill-into-evidence", "Open evidence", "Timesheets.ReadTimeEntryEvidence")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory)),
                new("report-row", "Report row", nameof(ActualTimeReportRowState)),
                new("reference-state", "Reference state", nameof(ActualTimeReferenceState)),
                new("hydration-state", "Hydration state", nameof(DisplayHydrationState)),
                new("ai-metrics", "AI metric availability", nameof(AiMetricAvailability)),
                new("ai-tokens", "AI token availability", nameof(AiTokenMetricAvailability)),
                new("ai-source", "AI metric source category", nameof(AiEffortMetricSourceCategory)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.projection.work-actual-time-report",
            "Work Actual-Time Report",
            "reporting",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("workFilter", "Work filter", "WorkReference", false, "Work references remain stable IDs; labels hydrate after authorization."),
                new("contributorFilter", "Contributor filter", "PartyReference", false, "Preserved during drill-in and back navigation."),
                new("activityTypeFilter", "Activity Type filter", nameof(ActivityTypeId), false),
                new("periodFilter", "Period filter", "TenantLocalPeriod", false, "Tenant-local period or date range."),
                new("billableFilter", "Billable filter", nameof(BillableState), false),
                new("approvalStateFilter", "Approval state filter", nameof(TimeEntryApprovalState), false),
                new("contributorCategoryFilter", "Contributor category filter", nameof(ContributorCategory), false),
                new("aiAgentFilter", "AI agent filter", "PartyReference", false, "Automated agent Party filter for AI effort rows."),
                new("aiMetricAvailabilityFilter", "AI metric availability filter", nameof(AiMetricAvailability), false),
                new("aiTokenAvailabilityFilter", "AI token availability filter", nameof(AiTokenMetricAvailability), false, "Unavailable and Not reported by provider are displayed as text."),
                new("aiSourceCategoryFilter", "AI source category filter", nameof(AiEffortMetricSourceCategory), false),
                new("currentRowsOnly", "Current rows only", "Boolean", true, "Superseded evidence is hidden unless explicitly requested."),
                new("includeSupersededRows", "Include superseded rows", "Boolean", false, "Shows superseded evidence only for reconciliation."),
                new("projectionFreshnessFilter", "Projection freshness filter", nameof(ProjectionFreshnessState), false),
                new("target", "Work reference", "WorkReference", true),
                new("tenantLocalPeriodKey", "Period", "TenantLocalPeriod", true),
                new("contributor", "Contributor", "PartyReference", true),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("billableState", "Billable state", nameof(BillableState), true),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("contributorCategory", "Contributor category", nameof(ContributorCategory), true),
                new("actualMinutes", "Actual minutes", "WholeMinutes", true),
                new("aiWallClockDurationMilliseconds", "AI wall-clock execution", "Milliseconds", false, "AI wall-clock execution stays separate from human and external minutes."),
                new("aiModelRuntimeMilliseconds", "AI model/tool runtime", "Milliseconds", false),
                new("aiBillableEffortMinutes", "AI billable effort", "WholeMinutes", false, "AI billable effort stays separate from actual minutes and provider token counts."),
                new("aiProviderInputTokenCount", "Provider input tokens", "Integer", false, "Unavailable token counts display Unavailable or Not reported by provider, never zero unless reported as zero."),
                new("aiProviderOutputTokenCount", "Provider output tokens", "Integer", false, "Unavailable token counts display Unavailable or Not reported by provider, never zero unless reported as zero."),
                new("aiProviderTotalTokenCount", "Provider total tokens", "Integer", false, "Provider-reported token count only."),
                new("aiMetricAvailability", "AI metric availability", nameof(AiMetricAvailability), true),
                new("aiTokenAvailability", "AI token availability", nameof(AiTokenMetricAvailability), true, "Unavailable or Not reported by provider."),
                new("aiMetricSourceCategory", "AI source category", nameof(AiEffortMetricSourceCategory), false),
                new("aiMetricSourceMetadata", "AI metric source metadata", nameof(AiEffortMetricSourceMetadata), false, "Compact provider, tool, or work execution reference only."),
                new("sourceRowCount", "Source rows", "Integer", true),
                new("correctionCount", "Corrections", "Integer", true),
                new("supersededCount", "Superseded rows", "Integer", true),
                new("referenceState", "Reference state", nameof(ActualTimeReferenceState), true),
                new("displayHydration", "Display hydration", nameof(TimeEntryDisplayHydration), true, "Labels are hydrated only after row authorization succeeds."),
                new("plannedEffortAvailability", "Planned effort availability", nameof(WorkPlannedEffortAvailability), true, "Works is the source when planned values are supplied."),
                new("plannedEstimated", "Works estimated effort", "Decimal", false),
                new("plannedDone", "Works done effort", "Decimal", false),
                new("plannedRemaining", "Works remaining effort", "Decimal", false),
                new("plannedUnit", "Works effort unit", "String", false),
                new("plannedSourceReferenceState", "Works source reference state", nameof(ActualTimeReferenceState), true),
                new("plannedSourceFreshness", "Works source freshness", nameof(ProjectionFreshnessState), true),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("query-work-actual-time-report", "Query Work report", "Timesheets.QueryWorkActualTimeReport"),
                new("open-project-actual-time-report", "Open Project report", "Timesheets.QueryProjectActualTimeReport"),
                new("drill-into-evidence", "Open evidence", "Timesheets.ReadTimeEntryEvidence")
            ],
            [
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("billable", "Billable", nameof(BillableState)),
                new("contributor", "Contributor", nameof(ContributorCategory)),
                new("report-row", "Report row", nameof(ActualTimeReportRowState)),
                new("reference-state", "Reference state", nameof(ActualTimeReferenceState)),
                new("hydration-state", "Hydration state", nameof(DisplayHydrationState)),
                new("planned-effort", "Planned effort availability", nameof(WorkPlannedEffortAvailability)),
                new("ai-metrics", "AI metric availability", nameof(AiMetricAvailability)),
                new("ai-tokens", "AI token availability", nameof(AiTokenMetricAvailability)),
                new("ai-source", "AI metric source category", nameof(AiEffortMetricSourceCategory)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.projection.my-timesheet-period",
            "My Timesheet Period",
            "submission",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("timesheetPeriodId", "Timesheet Period", nameof(TimesheetPeriodId), true),
                new("periodKind", "Period kind", nameof(TimesheetPeriodKind), true),
                new("periodState", "Period state", nameof(TimesheetPeriodApprovalState), true, "Period state stays separate from entry Approval State."),
                new("tenantTimeZoneId", "Tenant time-zone", "String", true),
                new("localBoundary", "Local boundary", nameof(TenantLocalPeriodBoundary), true),
                new("includedEntryCount", "Included entries", "Integer", true),
                new("timeEntries", "TimeEntry evidence", "TimeEntryEvidenceReadModel[]", true),
                new("entrySummaries", "Entry summaries", nameof(TimesheetPeriodEntrySummary), true, "Entry badges stay separate from period state."),
                new("blockingEntryGuidance", "Blocking-entry guidance", nameof(TimesheetPeriodBlockingEntryGuidance), false, "Entry needs correction."),
                new("rejectionReason", "Rejection reason", nameof(TimeEntryRejectionReason), false),
                new("approvedCorrection", "Approved correction evidence", nameof(TimeEntryApprovedCorrectionEvidence), false),
                new("correctionReason", "Correction reason", nameof(TimeEntryCorrectionReason), false),
                new("priorValues", "Prior values", nameof(TimeEntryCorrectionValues), false),
                new("correctedValues", "Corrected values", nameof(TimeEntryCorrectionValues), false),
                new("correctionState", "Correction state", nameof(TimeEntryCorrectionState), true),
                new("lockEvidence", "Lock evidence", nameof(TimeEntryLockEvidence), true, "Entry lock state is display evidence only; write authority remains the aggregate state."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), true),
                new("fieldValidation", "Field validation", "TimesheetsFieldError[]", false),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true),
                new("persistentMessageBarState", "Persistent message-bar state", "String", false, "Period correction and freshness blockers remain visible.")
            ],
            [
                new("submit-period", "Submit period", "Timesheets.SubmitTimesheetPeriod"),
                new("correct-entry", "Correct entry", "Timesheets.CorrectRejectedTimeEntry"),
                new("add-correction", "Add correction", "Timesheets.CorrectApprovedTimeEntry"),
                new("submit-time-entries", "Submit entries", "Timesheets.SubmitTimeEntriesForApproval")
            ],
            [
                new("period", "Period", nameof(TimesheetPeriodApprovalState)),
                new("period-kind", "Period kind", nameof(TimesheetPeriodKind)),
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("lock", "Lock", nameof(TimeEntryLockState)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.projection.period-approval-detail",
            "Period Approval Detail",
            "approval",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("timesheetPeriodId", "Timesheet Period", nameof(TimesheetPeriodId), true),
                new("periodState", "Period state", nameof(TimesheetPeriodApprovalState), true, "Period state stays separate from entry Approval State."),
                new("entrySummaries", "Entry summaries", nameof(TimesheetPeriodEntrySummary), true, "Entry rows show entry states separately from the period decision."),
                new("affectedEntryIds", "Affected entries", "TimeEntryId[]", false, "Affected entry ids remain grouped decision evidence."),
                new("periodDecision", "Period decision evidence", nameof(TimesheetPeriodApprovalDecisionEvidence), false, "Grouped approval or rejection decision evidence."),
                new("rejectedEntries", "Rejected entries", nameof(TimesheetPeriodSelectedEntryRejectionEvidence), false, "Selected rejected entries carry required reasons."),
                new("rejectionReason", "Rejection reason", nameof(TimesheetPeriodRejectionReason), false, "Period rejection reason is separate from entry rejection reasons."),
                new("authorityDecision", "Authority decision", nameof(ApprovalAuthorityDecisionState), true, "Authority cannot be resolved."),
                new("authoritySource", "Authority source", nameof(ApprovalAuthoritySource), false),
                new("authorityFreshness", "Authority freshness", nameof(ProjectionFreshnessState), true),
                new("lockEvidence", "Lock evidence", nameof(TimeEntryLockEvidence), true, "Entry lock state is derived from Time Entry approval events."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), true),
                new("blockingEntryGuidance", "Blocking-entry guidance", nameof(TimesheetPeriodBlockingEntryGuidance), false, "Entry needs correction."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true, "Projection is rebuilding."),
                new("persistentMessageBarState", "Persistent message-bar state", "String", true, "Authority cannot be resolved.")
            ],
            [
                new("approve-period", "Approve period", "Timesheets.ApprovePeriod"),
                new("reject-period", "Reject period", "Timesheets.RejectPeriod"),
                new("approve-entry", "Approve entry", "Timesheets.ApproveEntry"),
                new("reject-entry", "Reject entry", "Timesheets.RejectEntry"),
                new("correct-entry", "Correct entry", "Timesheets.CorrectRejectedTimeEntry")
            ],
            [
                new("period", "Period", nameof(TimesheetPeriodApprovalState)),
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("correction", "Correction", nameof(TimeEntryCorrectionState)),
                new("lock", "Lock", nameof(TimeEntryLockState)),
                new("authority-decision", "Authority decision", nameof(ApprovalAuthorityDecisionState)),
                new("authority-freshness", "Authority freshness", nameof(ProjectionFreshnessState)),
                new("authority-source", "Authority source", nameof(ApprovalAuthoritySource)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ]),
        new(
            "timesheets.approvals.queue",
            "Approvals Queue",
            "approval",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("timeEntry", "Time Entry", "TimeEntryId", false),
                new("period", "Period", "String", false),
                new("approvalState", "Approval state", nameof(TimeEntryApprovalState), true),
                new("lockEvidence", "Lock evidence", nameof(TimeEntryLockEvidence), false, "Approved entries show direct-edit lock evidence."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), false),
                new("approvedCorrection", "Approved correction evidence", nameof(TimeEntryApprovedCorrectionEvidence), false),
                new("correctionReason", "Correction reason", nameof(TimeEntryCorrectionReason), false),
                new("authorityDecision", "Authority decision", nameof(ApprovalAuthorityDecisionState), true),
                new("authoritySource", "Authority source", nameof(ApprovalAuthoritySource), true, "Stable source attribution for the policy decision."),
                new("authorityFreshness", "Authority freshness", nameof(ProjectionFreshnessState), true),
                new("blockingState", "Blocking state", "String", true, "Authority cannot be resolved."),
                new("persistentMessageBarState", "Persistent message-bar state", "String", true, "Authority cannot be resolved.")
            ],
            [
                new("approve-entry", "Approve entry", "Timesheets.ApproveEntry"),
                new("reject-entry", "Reject entry", "Timesheets.RejectEntry"),
                new("add-correction", "Add correction", "Timesheets.CorrectApprovedTimeEntry"),
                new("approve-period", "Approve period", "Timesheets.ApprovePeriod"),
                new("reject-period", "Reject period", "Timesheets.RejectPeriod")
            ],
            [
                new("authority-decision", "Authority decision", nameof(ApprovalAuthorityDecisionState)),
                new("authority-freshness", "Authority freshness", nameof(ProjectionFreshnessState)),
                new("authority-source", "Authority source", nameof(ApprovalAuthoritySource)),
                new("approval", "Approval", nameof(TimeEntryApprovalState)),
                new("lock", "Lock", nameof(TimeEntryLockState))
            ]),
        new(
            "timesheets.command.time-entry-approval",
            "Time Entry Approval",
            "approval",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("timeEntry", "Time Entry", "TimeEntryId", true),
                new("approvalAction", "Approval action", nameof(ApprovalAuthorityAction), true),
                new("authorityDecision", "Authority decision", nameof(ApprovalAuthorityDecisionState), true),
                new("authoritySource", "Authority source", nameof(ApprovalAuthoritySource), false),
                new("authorityFreshness", "Authority freshness", nameof(ProjectionFreshnessState), true),
                new("blockingState", "Blocking state", "String", false, "Authority cannot be resolved.")
            ],
            [
                new("approve-entry", "Approve entry", "Timesheets.ApproveEntry"),
                new("reject-entry", "Reject entry", "Timesheets.RejectEntry")
            ],
            [
                new("authority-decision", "Authority decision", nameof(ApprovalAuthorityDecisionState)),
                new("authority-freshness", "Authority freshness", nameof(ProjectionFreshnessState)),
                new("authority-source", "Authority source", nameof(ApprovalAuthoritySource))
            ]),
        new(
            "timesheets.command.period-approval",
            "Period Approval",
            "approval",
            TimesheetsSurfaceKind.Command,
            TimesheetsCompositionPattern.FrontComposerGeneratedForm,
            [
                new("period", "Period", "String", true),
                new("timesheetPeriodId", "Timesheet Period", nameof(TimesheetPeriodId), true),
                new("periodState", "Period state", nameof(TimesheetPeriodApprovalState), true, "Period state stays separate from entry Approval State."),
                new("affectedEntryIds", "Affected entries", "TimeEntryId[]", false),
                new("rejectedEntries", "Rejected entries", nameof(TimesheetPeriodSelectedEntryRejectionEvidence), false, "Entry needs correction."),
                new("rejectionReason", "Rejection reason", nameof(TimesheetPeriodRejectionReason), false),
                new("lockState", "Lock state", nameof(TimeEntryLockState), false),
                new("approvalAction", "Approval action", nameof(ApprovalAuthorityAction), true),
                new("authorityDecision", "Authority decision", nameof(ApprovalAuthorityDecisionState), true),
                new("authoritySource", "Authority source", nameof(ApprovalAuthoritySource), false),
                new("authorityFreshness", "Authority freshness", nameof(ProjectionFreshnessState), true),
                new("blockingState", "Blocking state", "String", false, "Authority cannot be resolved.")
            ],
            [
                new("approve-period", "Approve period", "Timesheets.ApprovePeriod"),
                new("reject-period", "Reject period", "Timesheets.RejectPeriod")
            ],
            [
                new("authority-decision", "Authority decision", nameof(ApprovalAuthorityDecisionState)),
                new("authority-freshness", "Authority freshness", nameof(ProjectionFreshnessState)),
                new("authority-source", "Authority source", nameof(ApprovalAuthoritySource))
            ]),
        new(
            "timesheets.review.export-policy",
            "Export policy review",
            "evidence",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("retentionCategory", "Retention category", nameof(TimesheetsEvidenceRetentionCategory), true),
                new("commentExport", "Comment export", nameof(TimesheetsCommentPolicyDecision), true, "Export comments only when policy allows it."),
                new("diagnostics", "Diagnostics", nameof(TimesheetsCommentPolicyDecision), true, "Comments are excluded from diagnostics."),
                new("lockState", "Lock state", nameof(TimeEntryLockState), false, "Future ledger and report surfaces display approved-entry lock state as read evidence.")
            ],
            [],
            [
                new("retention-posture", "Retention posture", nameof(TimesheetsRetentionPosture)),
                new("comment-policy", "Comment policy", nameof(TimesheetsCommentPolicyDecision)),
                new("lock", "Lock", nameof(TimeEntryLockState))
            ]),
        new(
            "timesheets.projection.magic-link-confirmation-capabilities",
            "Magic-Link Confirmation Requests",
            "external-contribution",
            TimesheetsSurfaceKind.Projection,
            TimesheetsCompositionPattern.FrontComposerProjectionView,
            [
                new("capabilityId", "Capability ID", nameof(MagicLinkCapabilityId), true),
                new("contributor", "Contributor", "PartyReference", true),
                new("target", "Target reference", "TimeEntryTargetReference", true),
                new("activityType", "Activity Type", nameof(ActivityTypeId), true),
                new("timeEntry", "Time Entry", nameof(TimeEntryId), true),
                new("targetKind", "Target kind", nameof(MagicLinkTargetKind), true),
                new("allowedAction", "Allowed action", nameof(MagicLinkAllowedAction), true),
                new("state", "State", nameof(MagicLinkCapabilityState), true),
                new("stateBadgeText", "State status", "String", true, "Status is shown with text, not color alone."),
                new("expiryState", "Expiry state", nameof(MagicLinkExpiryState), true),
                new("expiryBadgeText", "Expiry status", "String", true, "Expiry status is shown with text, not color alone."),
                new("expiresAtUtc", "Expires", "DateTimeOffset", true),
                new("issuer", "Issuer", "PartyReference", true),
                new("issuedAtUtc", "Issued", "DateTimeOffset", true),
                new("usedAtUtc", "Used", "DateTimeOffset", false),
                new("auditMetadata", "Audit metadata", nameof(MagicLinkAuditMetadata), false, "Safe source system and idempotency reference only."),
                new("projectionFreshness", "Projection freshness", nameof(ProjectionFreshnessState), true)
            ],
            [
                new("issue-confirmation-capability", "Issue confirmation request", "Timesheets.IssueMagicLinkConfirmationCapability"),
                new("revoke-confirmation-capability", "Revoke confirmation request", "Timesheets.RevokeMagicLinkConfirmationCapability"),
                new("expire-confirmation-capability", "Expire confirmation request", "Timesheets.ExpireMagicLinkConfirmationCapability")
            ],
            [
                new("magic-link-state", "Magic-link state", nameof(MagicLinkCapabilityState)),
                new("magic-link-expiry", "Magic-link expiry", nameof(MagicLinkExpiryState)),
                new("allowed-action", "Allowed action", nameof(MagicLinkAllowedAction)),
                new("projection-freshness", "Projection freshness", nameof(ProjectionFreshnessState))
            ])
    ];
}
