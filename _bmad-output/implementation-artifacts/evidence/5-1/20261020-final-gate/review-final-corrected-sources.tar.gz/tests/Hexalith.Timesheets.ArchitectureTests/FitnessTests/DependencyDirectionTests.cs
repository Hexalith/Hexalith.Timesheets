using System.Xml.Linq;

using Shouldly;

namespace Hexalith.Timesheets.ArchitectureTests.FitnessTests;

public sealed class DependencyDirectionTests
{
    private static readonly string[] ForbiddenContractsReferences =
    [
        "Dapr",
        "Aspire",
        "Microsoft.AspNetCore",
        "Microsoft.FluentUI",
        "OpenTelemetry",
        "StackExchange.Redis",
        "EntityFrameworkCore"
    ];

    private static readonly string[] ForbiddenKernelReferences =
    [
        "Dapr",
        "Aspire",
        "Microsoft.AspNetCore",
        "Microsoft.FluentUI",
        "OpenTelemetry",
        "StackExchange.Redis",
        "EntityFrameworkCore",
        "ModelContextProtocol",
        "OpenAI",
        "SemanticKernel"
    ];

    [Fact]
    public void Contracts_project_has_no_infrastructure_runtime_or_ui_dependencies()
    {
        string projectPath = RepositoryRoot.PathTo(
            "src",
            "Hexalith.Timesheets.Contracts",
            "Hexalith.Timesheets.Contracts.csproj");

        XDocument project = XDocument.Load(projectPath);
        string[] references = ReadIncludeValues(project).ToArray();

        foreach (string forbidden in ForbiddenContractsReferences)
        {
            references.ShouldNotContain(reference => reference.Contains(forbidden, StringComparison.OrdinalIgnoreCase));
        }
    }

    [Fact]
    public void Public_command_and_query_contracts_do_not_expose_server_authority_or_envelope_fields()
    {
        string contractsRoot = RepositoryRoot.PathTo("src", "Hexalith.Timesheets.Contracts");
        string[] contractFiles =
        [
            .. Directory.GetFiles(Path.Combine(contractsRoot, "Commands"), "*.cs", SearchOption.AllDirectories),
            .. Directory.GetFiles(Path.Combine(contractsRoot, "Queries"), "*.cs", SearchOption.AllDirectories)
        ];

        contractFiles.ShouldNotBeEmpty();

        string[] forbiddenTerms =
        [
            "TenantId",
            "UserId",
            "CorrelationId",
            "MessageId",
            "CausationId",
            "ClaimsPrincipal",
            "Authorization",
            "Jwt",
            "Token",
            "Stream",
            "Sequence"
        ];

        foreach (string contractFile in contractFiles)
        {
            string source = RemoveAllowedDomainTokenMetricTerms(File.ReadAllText(contractFile));

            foreach (string forbiddenTerm in forbiddenTerms)
            {
                source.Contains(forbiddenTerm, StringComparison.Ordinal).ShouldBeFalse(contractFile);
            }
        }
    }

    // "Token" is forbidden in contracts to block auth/bearer tokens and other credentials from
    // leaking into public command/query bodies. The AI-effort domain legitimately uses provider
    // token-metric vocabulary, which is not a credential. Only these exact identifiers are exempt;
    // any other "...Token..." member (e.g. AuthToken, AccessToken) still trips the scan because the
    // surrounding identifier survives the removal. Longest identifier is stripped first so the
    // shorter one cannot partially consume it.
    private static readonly string[] AllowedDomainTokenMetricIdentifiers =
    [
        "AiTokenMetricAvailability",
        "AiTokenAvailability"
    ];

    private static string RemoveAllowedDomainTokenMetricTerms(string source)
    {
        foreach (string allowed in AllowedDomainTokenMetricIdentifiers)
        {
            source = source.Replace(allowed, string.Empty, StringComparison.Ordinal);
        }

        return source;
    }

    [Fact]
    public void Kernel_projects_do_not_reference_runtime_hosting_ui_or_direct_persistence_packages()
    {
        string[] kernelProjects =
        [
            RepositoryRoot.PathTo("src", "Hexalith.Timesheets.Server", "Hexalith.Timesheets.Server.csproj"),
            RepositoryRoot.PathTo("src", "Hexalith.Timesheets.Projections", "Hexalith.Timesheets.Projections.csproj")
        ];

        foreach (string projectPath in kernelProjects)
        {
            XDocument project = XDocument.Load(projectPath);
            string[] references = ReadIncludeValues(project).ToArray();

            foreach (string forbidden in ForbiddenKernelReferences)
            {
                references.ShouldNotContain(reference => reference.Contains(forbidden, StringComparison.OrdinalIgnoreCase), projectPath);
            }
        }
    }

    [Fact]
    public void Contracts_take_no_works_or_eventstore_reference_and_server_takes_no_works_reference()
    {
        // Contracts stay infrastructure-free. Server may reference the EventStore SDK for the owned
        // Story 3.6 magic-link state loader, but Works remains isolated behind Hexalith.Timesheets.Works.
        AssertNoReferences(
            RepositoryRoot.PathTo("src", "Hexalith.Timesheets.Contracts", "Hexalith.Timesheets.Contracts.csproj"),
            "Hexalith.Works",
            "Hexalith.EventStore");
        AssertNoReferences(
            RepositoryRoot.PathTo("src", "Hexalith.Timesheets.Server", "Hexalith.Timesheets.Server.csproj"),
            "Hexalith.Works");
    }

    /// <summary>Preserves sibling boundaries while allowing the conditional published-package graph.</summary>
    [Fact]
    public void Sibling_modules_use_conditional_source_and_published_package_references()
    {
        string repositoryRoot = RepositoryRoot.Find().FullName;
        string[] projectFiles =
        [
            .. Directory.GetFiles(Path.Combine(repositoryRoot, "src"), "*.csproj", SearchOption.AllDirectories),
            .. Directory.GetFiles(Path.Combine(repositoryRoot, "tests"), "*.csproj", SearchOption.AllDirectories),
        ];

        projectFiles.ShouldNotBeEmpty();

        foreach (string projectFile in projectFiles)
        {
            XDocument project = XDocument.Load(projectFile);
            XElement[] packageReferences = project
                .Descendants("PackageReference")
                .Where(static reference => reference.Attribute("Include")?.Value.StartsWith("Hexalith.", StringComparison.Ordinal) == true)
                .ToArray();

            foreach (XElement reference in packageReferences)
            {
                string package = reference.Attribute("Include")!.Value;
                (package.StartsWith("Hexalith.EventStore.", StringComparison.Ordinal)
                    || package == "Hexalith.Works.Contracts").ShouldBeTrue(projectFile);
                string.Join(";", reference.AncestorsAndSelf().Attributes("Condition").Select(static value => value.Value))
                    .Contains("'$(UseHexalithProjectReferences)' != 'true'", StringComparison.Ordinal).ShouldBeTrue(projectFile);
            }

            foreach (XElement reference in project.Descendants("ProjectReference")
                .Where(static reference => reference.Attribute("Include")?.Value.StartsWith("$(Hexalith", StringComparison.Ordinal) == true))
            {
                reference.Attribute("Condition")?.Value.ShouldBe("'$(UseHexalithProjectReferences)' == 'true'", projectFile);
            }
        }
    }

    [Fact]
    public void Directory_build_props_detects_required_root_level_sibling_modules()
    {
        string props = File.ReadAllText(RepositoryRoot.PathTo("Directory.Build.props"));

        foreach (string propertyName in new[]
        {
            "HexalithEventStoreRoot",
            "HexalithTenantsRoot",
            "HexalithPartiesRoot",
            "HexalithProjectsRoot",
            "HexalithWorksRoot",
            "HexalithFrontComposerRoot",
            "HexalithCommonsRoot"
        })
        {
            props.ShouldContain(propertyName);
        }

        props.ShouldContain(@"references\Hexalith.");
        props.ShouldNotContain("Exists('$(MSBuildThisFileDirectory)Hexalith.");
    }

    [Fact]
    public void Timesheets_host_discovers_projection_handlers_and_maps_canonical_sdk_routes()
    {
        string hostProject = File.ReadAllText(RepositoryRoot.PathTo(
            "src", "Hexalith.Timesheets", "Hexalith.Timesheets.csproj"));
        string projectionsProject = File.ReadAllText(RepositoryRoot.PathTo(
            "src", "Hexalith.Timesheets.Projections", "Hexalith.Timesheets.Projections.csproj"));
        string program = File.ReadAllText(RepositoryRoot.PathTo("src", "Hexalith.Timesheets", "Program.cs"));
        string indexHandler = File.ReadAllText(RepositoryRoot.PathTo(
            "src", "Hexalith.Timesheets.Projections", "MagicLinks", "MagicLinkTokenHashCapabilityIndexProjectionHandler.cs"));
        string catalogHandler = File.ReadAllText(RepositoryRoot.PathTo(
            "src", "Hexalith.Timesheets.Projections", "ActivityTypes", "TenantActivityTypeCatalogProjectionHandler.cs"));

        hostProject.ShouldContain("Hexalith.Timesheets.Projections");
        // Deliberately not asserted: the Projections -> Server project reference. It is the layering
        // inversion decision 3 resolves by moving the four shared shapes to Contracts, so pinning it
        // here would make that follow-up start by deleting this assertion.
        projectionsProject.ShouldContain("Hexalith.EventStore.DomainService");
        program.ShouldContain("AddEventStoreDomainService");
        program.ShouldContain("TimesheetsProjectionsMarker");
        program.ShouldContain("UseEventStoreDomainService");
        indexHandler.ShouldContain("IAsyncDomainSharedProjectionStreamedOwnerHandler");
        catalogHandler.ShouldContain("IAsyncDomainSharedProjectionRebuildHandler");
        indexHandler.ShouldContain("ReadModelWritePolicy.UpdateAsync");
        catalogHandler.ShouldContain("ReadModelWritePolicy.UpdateAsync");
    }

    [Fact]
    public void Timesheets_host_delegates_shared_defaults_to_the_eventstore_sdk_once()
    {
        string hostProject = File.ReadAllText(RepositoryRoot.PathTo(
            "src", "Hexalith.Timesheets", "Hexalith.Timesheets.csproj"));
        string program = File.ReadAllText(RepositoryRoot.PathTo("src", "Hexalith.Timesheets", "Program.cs"));

        program.Split("AddEventStoreDomainService(", StringSplitOptions.None).Length.ShouldBe(2);
        program.ShouldNotContain("AddTimesheetsServiceDefaults");
        // Deliberately not asserted: that the host still carries the ServiceDefaults project
        // reference. It is orphaned by this host composition and decision 5 owns its disposition,
        // so cementing the orphan here would make that follow-up start by deleting this assertion.
    }

    private static IEnumerable<string> ReadIncludeValues(XDocument project)
    {
        return project
            .Descendants()
            .Where(static element => element.Name.LocalName is "PackageReference" or "ProjectReference" or "FrameworkReference")
            .Select(static element => element.Attribute("Include")?.Value)
            .Where(static value => value is not null)
            .Cast<string>();
    }

    private static void AssertNoReferences(string projectPath, params string[] forbiddenReferences)
    {
        XDocument project = XDocument.Load(projectPath);
        string[] references = ReadIncludeValues(project).ToArray();

        foreach (string forbidden in forbiddenReferences)
        {
            references.ShouldNotContain(
                reference => reference.Contains(forbidden, StringComparison.OrdinalIgnoreCase),
                projectPath);
        }
    }
}
